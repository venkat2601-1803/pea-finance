"""
Personal Expenses Analysis (PEA) - Main Application Entry Point
Registers decoupled Admin Module and User Module blueprints.
"""

import os
from flask import Flask, session, request, jsonify, redirect, url_for
import data_manager

# Import decoupled modules
from modules.admin_module import admin_bp
from modules.user_module import user_bp

app = Flask(__name__)
app.config['SECRET_KEY'] = 'pea-secret-key-2026'
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0

# Initialize database schema & migrations
data_manager.init_db()

# Register modular blueprints
app.register_blueprint(admin_bp)
app.register_blueprint(user_bp)


@app.context_processor
def inject_globals():
    """Injects feature flags and user session globals into Jinja templates."""
    return {
        'features': data_manager.get_feature_flags_dict(),
        'user_role': session.get('role', 'user'),
        'username': session.get('username', '')
    }


@app.before_request
def require_login():
    """Enforces global authentication for all protected routes across modules."""
    open_endpoints = [
        'user_module.root',
        'user_module.login',
        'user_module.register',
        'user_module.logout',
        'user_module.api_login',
        'user_module.api_register',
        'user_module.api_auth_status',
        'static'
    ]
    if request.endpoint in open_endpoints or (request.path and request.path.startswith('/static/')):
        return None

    if 'user_id' not in session:
        if request.path.startswith('/api/'):
            return jsonify({"success": False, "error": "Authentication required. Please log in."}), 401
        return redirect(url_for('user_module.login', next=request.url))


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    print(f"Starting Personal Expenses Analysis (PEA) application on http://0.0.0.0:{port} ...")
    app.run(host='0.0.0.0', port=port, debug=True)
