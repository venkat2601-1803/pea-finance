"""
Personal Expenses Analysis (PEA) - Data Manager
Handles SQLite persistence, CSV import/export, and realistic Indian Rupees (INR) sample data generation.
"""

import os
import sqlite3
import datetime
import random
import pandas as pd
import numpy as np
from werkzeug.security import generate_password_hash, check_password_hash

DB_PATH = os.path.join(os.path.dirname(__file__), 'data', 'expenses.db')

DEFAULT_CATEGORIES = [
    "Food & Dining",
    "Transportation",
    "Education",
    "Shopping",
    "Bills & Utilities",
    "Entertainment",
    "Healthcare",
    "Others"
]

# Monthly budgets in Indian Rupees (₹ INR)
DEFAULT_BUDGETS = {
    "Food & Dining": 15000.0,
    "Transportation": 6000.0,
    "Education": 8000.0,
    "Shopping": 7000.0,
    "Bills & Utilities": 10000.0,
    "Entertainment": 5000.0,
    "Healthcare": 4000.0,
    "Others": 3000.0
}

PAYMENT_METHODS = [
    "UPI (GPay / PhonePe / Paytm)",
    "Credit Card",
    "Debit Card",
    "Net Banking",
    "Cash"
]


def get_db_connection():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db(force_reseed=False):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            title TEXT NOT NULL,
            category TEXT NOT NULL,
            amount REAL NOT NULL,
            payment_method TEXT NOT NULL,
            notes TEXT DEFAULT ''
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS budgets (
            category TEXT PRIMARY KEY,
            monthly_budget REAL NOT NULL
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT DEFAULT 'user',
            is_active INTEGER DEFAULT 1,
            created_at TEXT NOT NULL
        )
    ''')

    # Migration helpers for existing tables
    try:
        cursor.execute("ALTER TABLE users ADD COLUMN role TEXT DEFAULT 'user'")
    except sqlite3.OperationalError:
        pass

    try:
        cursor.execute("ALTER TABLE users ADD COLUMN is_active INTEGER DEFAULT 1")
    except sqlite3.OperationalError:
        pass

    try:
        cursor.execute("ALTER TABLE expenses ADD COLUMN user_id INTEGER DEFAULT 1")
    except sqlite3.OperationalError:
        pass

    try:
        cursor.execute("ALTER TABLE expenses ADD COLUMN frequency TEXT DEFAULT 'daily'")
    except sqlite3.OperationalError:
        pass

    try:
        cursor.execute("ALTER TABLE users ADD COLUMN full_name TEXT DEFAULT ''")
    except sqlite3.OperationalError:
        pass

    try:
        cursor.execute("ALTER TABLE users ADD COLUMN email TEXT DEFAULT ''")
    except sqlite3.OperationalError:
        pass

    try:
        cursor.execute("ALTER TABLE users ADD COLUMN phone TEXT DEFAULT ''")
    except sqlite3.OperationalError:
        pass

    # Feature Flags Table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS feature_flags (
            feature_key TEXT PRIMARY KEY,
            feature_name TEXT NOT NULL,
            description TEXT NOT NULL,
            is_enabled INTEGER DEFAULT 1,
            category TEXT DEFAULT 'general'
        )
    ''')

    # General App Settings Table (for persisting constant monthly budget, etc.)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS settings (
            setting_key TEXT PRIMARY KEY,
            setting_value TEXT NOT NULL
        )
    ''')

    now_str = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    # Ensure default admin user
    cursor.execute('SELECT id FROM users WHERE LOWER(username) = LOWER(?)', ('admin',))
    if not cursor.fetchone():
        admin_hash = generate_password_hash('admin123')
        cursor.execute('INSERT INTO users (username, password_hash, role, is_active, created_at) VALUES (?, ?, ?, ?, ?)',
                       ('admin', admin_hash, 'admin', 1, now_str))
    else:
        cursor.execute("UPDATE users SET role = 'admin' WHERE username = 'admin'")

    # Ensure default standard user (user / user123)
    cursor.execute('SELECT id FROM users WHERE LOWER(username) = LOWER(?)', ('user',))
    if not cursor.fetchone():
        user_hash = generate_password_hash('user123')
        cursor.execute('INSERT INTO users (username, password_hash, role, is_active, created_at) VALUES (?, ?, ?, ?, ?)',
                       ('user', user_hash, 'user', 1, now_str))

    # Seed default feature flags if empty
    cursor.execute('SELECT COUNT(*) FROM feature_flags')
    if cursor.fetchone()[0] == 0:
        default_features = [
            ('deep_analytics', 'Deep Financial Analytics', 'Detailed analytics, moving averages, anomaly detection, and payment method distribution', 1, 'analytics'),
            ('budget_planner', 'Budget Planner (₹)', 'Category monthly targets, budget allocation, and variance tracking', 1, 'planning'),
            ('pdf_export', 'PDF Executive Reports', 'One-click PDF financial summary export', 1, 'export'),
            ('excel_export', 'Excel Ledger Export', 'Full spreadsheet download of expense transactions in .xlsx format', 1, 'export'),
            ('spreadsheet_upload', 'CSV/Excel Dataset Upload', 'Import external expense spreadsheets into the database', 1, 'data'),
            ('monthly_recurring', 'Monthly & Daily Expense Tracker', 'Track daily expenses vs monthly recurring bills and subscriptions', 1, 'expenses')
        ]
        cursor.executemany('''
            INSERT INTO feature_flags (feature_key, feature_name, description, is_enabled, category)
            VALUES (?, ?, ?, ?, ?)
        ''', default_features)

    cursor.execute('SELECT COUNT(*) FROM expenses')
    if cursor.fetchone()[0] == 0:
        today = datetime.date.today()
        d_str = lambda days_ago: (today - datetime.timedelta(days=days_ago)).strftime('%Y-%m-%d')
        default_expenses = [
            (d_str(0), 'Swiggy Dinner Order', 'Food & Dining', 450.00, 'UPI (GPay / PhonePe / Paytm)', 'Dinner with friends', 'daily', 1),
            (d_str(1), 'Grocery Supermarket', 'Grocery', 1850.50, 'Credit Card', 'Weekly household groceries', 'weekly', 1),
            (d_str(2), 'Fuel / Petrol Refill', 'Transportation', 1200.00, 'UPI (GPay / PhonePe / Paytm)', 'Bike fuel refill', 'weekly', 1),
            (d_str(3), 'Electricity Bill Payment', 'Utilities', 2450.00, 'Net Banking', 'Monthly electricity bill', 'monthly', 1),
            (d_str(4), 'Amazon Online Shopping', 'Shopping', 3200.00, 'Credit Card', 'Electronics accessories', 'monthly', 1),
            (d_str(5), 'Netflix Subscription', 'Entertainment', 649.00, 'Credit Card', 'Monthly OTT Streaming', 'monthly', 1),
            (d_str(6), 'Pharmacy Medicines', 'Medical/Health', 850.00, 'UPI (GPay / PhonePe / Paytm)', 'Health supplements', 'daily', 1),
            (d_str(8), 'House Rent', 'Housing/Rent', 15000.00, 'Net Banking', 'Monthly Apartment Rent', 'monthly', 1)
        ]
        cursor.executemany('''
            INSERT INTO expenses (date, title, category, amount, payment_method, notes, frequency, user_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', default_expenses)

    cursor.execute('SELECT COUNT(*) FROM budgets')
    count = cursor.fetchone()[0]

    conn.commit()
    conn.close()


def create_user(username, password, role='user'):
    """Creates a new user record. Returns (user_dict, error_msg)."""
    username = (username or '').strip()
    password = password or ''
    if not username or not password:
        return None, "Username and password are required."
    if len(username) < 3:
        return None, "Username must be at least 3 characters long."
    if len(password) < 4:
        return None, "Password must be at least 4 characters long."

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT id FROM users WHERE LOWER(username) = LOWER(?)', (username,))
    if cursor.fetchone():
        conn.close()
        return None, "Username already exists. Please choose a different username."

    pw_hash = generate_password_hash(password)
    now_str = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    try:
        cursor.execute('''
            INSERT INTO users (username, password_hash, role, is_active, created_at)
            VALUES (?, ?, ?, 1, ?)
        ''', (username, pw_hash, role, now_str))
        user_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return {"id": user_id, "username": username, "role": role}, None
    except sqlite3.IntegrityError:
        conn.close()
        return None, "Username already exists."


def verify_user(username, password):
    """Verifies user credentials. Returns user dict if valid, else None or error dict."""
    username = (username or '').strip()
    password = password or ''
    if not username or not password:
        return None

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT id, username, password_hash, role, is_active FROM users WHERE LOWER(username) = LOWER(?)', (username,))
    row = cursor.fetchone()
    conn.close()

    if row and check_password_hash(row['password_hash'], password):
        if not row['is_active']:
            return {"error": "Your account has been deactivated by an administrator."}
        return {"id": row['id'], "username": row['username'], "role": row['role'] or 'user'}
    return None


def update_admin_credentials(admin_id, new_admin_name, new_admin_password=None):
    """Updates Admin Name and optional Admin Password for administrator account."""
    new_admin_name = (new_admin_name or '').strip()
    if not new_admin_name or len(new_admin_name) < 3:
        return False, "Admin Name must be at least 3 characters long."

    conn = get_db_connection()
    cursor = conn.cursor()

    # Check if name is taken by another account
    cursor.execute('SELECT id FROM users WHERE LOWER(username) = LOWER(?) AND id != ?', (new_admin_name, admin_id))
    if cursor.fetchone():
        conn.close()
        return False, "Admin Name is already taken by another account."

    if new_admin_password and len(new_admin_password) >= 4:
        pw_hash = generate_password_hash(new_admin_password)
        cursor.execute('UPDATE users SET username = ?, password_hash = ? WHERE id = ?', (new_admin_name, pw_hash, admin_id))
    elif new_admin_password and len(new_admin_password) < 4:
        conn.close()
        return False, "Admin Password must be at least 4 characters long."
    else:
        cursor.execute('UPDATE users SET username = ? WHERE id = ?', (new_admin_name, admin_id))

    conn.commit()
    conn.close()
    return True, "Admin credentials updated successfully."


def get_user_profile(user_id):
    """Retrieves complete profile details and financial stats for a specific user."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT id, username, role, is_active, created_at,
               COALESCE(full_name, '') as full_name,
               COALESCE(email, '') as email,
               COALESCE(phone, '') as phone
        FROM users
        WHERE id = ?
    ''', (user_id,))
    row = cursor.fetchone()
    if not row:
        conn.close()
        return None

    # Get user expense statistics
    cursor.execute('''
        SELECT COUNT(*) as count, COALESCE(SUM(amount), 0.0) as total_spent
        FROM expenses
        WHERE user_id = ?
    ''', (user_id,))
    stats = cursor.fetchone()
    conn.close()

    user_data = dict(row)
    user_data['expense_count'] = stats['count'] if stats else 0
    user_data['total_spent'] = float(stats['total_spent']) if stats else 0.0
    return user_data


def update_user_profile(user_id, username=None, full_name=None, email=None, phone=None, current_password=None, new_password=None):
    """Updates user profile information and/or password with strict validation."""
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute('''
        SELECT id, username, password_hash,
               COALESCE(full_name, '') as full_name,
               COALESCE(email, '') as email,
               COALESCE(phone, '') as phone
        FROM users WHERE id = ?
    ''', (user_id,))
    user = cursor.fetchone()
    if not user:
        conn.close()
        return False, "User account not found.", None

    # Determine username
    if username is not None:
        clean_username = username.strip()
        if clean_username != user['username']:
            if len(clean_username) < 3:
                conn.close()
                return False, "Username must be at least 3 characters long.", None
            cursor.execute('SELECT id FROM users WHERE LOWER(username) = LOWER(?) AND id != ?', (clean_username, user_id))
            if cursor.fetchone():
                conn.close()
                return False, "Username is already taken by another account.", None
        elif not clean_username:
            clean_username = user['username']
    else:
        clean_username = user['username']

    # Determine full_name, email, phone (preserve if None)
    clean_fullname = full_name.strip() if full_name is not None else user['full_name']
    clean_email = email.strip() if email is not None else user['email']
    clean_phone = phone.strip() if phone is not None else user['phone']

    # Handle password change
    update_password = False
    new_pw_hash = None
    if new_password:
        if not current_password:
            conn.close()
            return False, "Current password is required to verify identity before setting a new password.", None
        if not check_password_hash(user['password_hash'], current_password):
            conn.close()
            return False, "Incorrect current password. Please enter your existing password to authorize the change.", None
        if len(new_password) < 4:
            conn.close()
            return False, "New password must be at least 4 characters long.", None
        new_pw_hash = generate_password_hash(new_password)
        update_password = True

    if update_password:
        cursor.execute('''
            UPDATE users
            SET username = ?, full_name = ?, email = ?, phone = ?, password_hash = ?
            WHERE id = ?
        ''', (clean_username, clean_fullname, clean_email, clean_phone, new_pw_hash, user_id))
    else:
        cursor.execute('''
            UPDATE users
            SET username = ?, full_name = ?, email = ?, phone = ?
            WHERE id = ?
        ''', (clean_username, clean_fullname, clean_email, clean_phone, user_id))

    conn.commit()
    conn.close()

    updated = get_user_profile(user_id)
    return True, "Profile details updated successfully.", updated


# ----------------------------------------------------
# Admin User & Feature Management Functions
# ----------------------------------------------------

def get_all_users():
    """Returns list of all registered users with their expense counts for admin panel."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT u.id, u.username, u.role, u.is_active, u.created_at,
               (SELECT COUNT(*) FROM expenses e WHERE e.user_id = u.id) as expense_count
        FROM users u
        ORDER BY u.id ASC
    ''')
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def update_user_role(user_id, role):
    """Updates user role ('admin' or 'user')."""
    if role not in ('admin', 'user'):
        return False, "Invalid role specified."
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('UPDATE users SET role = ? WHERE id = ?', (role, user_id))
    conn.commit()
    conn.close()
    return True, "User role updated successfully."


def update_user_status(user_id, is_active):
    """Toggles user active/inactive status."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('UPDATE users SET is_active = ? WHERE id = ?', (1 if is_active else 0, user_id))
    conn.commit()
    conn.close()
    return True, "User status updated."


def reset_user_password(user_id, new_password):
    """Resets user password."""
    if not new_password or len(new_password) < 4:
        return False, "Password must be at least 4 characters long."
    pw_hash = generate_password_hash(new_password)
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('UPDATE users SET password_hash = ? WHERE id = ?', (pw_hash, user_id))
    conn.commit()
    conn.close()
    return True, "Password reset successfully."


def delete_user(user_id):
    """Deletes user and user expenses."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM expenses WHERE user_id = ?', (user_id,))
    cursor.execute('DELETE FROM users WHERE id = ?', (user_id,))
    conn.commit()
    conn.close()
    return True, "User deleted successfully."


def get_feature_flags():
    """Returns dictionary/list of all feature flags."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT feature_key, feature_name, description, is_enabled, category FROM feature_flags ORDER BY feature_name ASC')
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_feature_flags_dict():
    """Returns {feature_key: is_enabled_bool} dictionary for template/API fast lookups."""
    flags = get_feature_flags()
    return {f['feature_key']: bool(f['is_enabled']) for f in flags}


def toggle_feature_flag(feature_key, is_enabled):
    """Toggles a feature flag ON/OFF."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('UPDATE feature_flags SET is_enabled = ? WHERE feature_key = ?', (1 if is_enabled else 0, feature_key))
    conn.commit()
    conn.close()
    return True


def add_feature_flag(feature_key, feature_name, description, is_enabled=1, category='general'):
    """Adds a new feature flag."""
    key_clean = feature_key.strip().lower().replace(' ', '_')
    if not key_clean or not feature_name:
        return False, "Feature key and name are required."

    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute('''
            INSERT INTO feature_flags (feature_key, feature_name, description, is_enabled, category)
            VALUES (?, ?, ?, ?, ?)
        ''', (key_clean, feature_name, description or '', 1 if is_enabled else 0, category or 'general'))
        conn.commit()
        conn.close()
        return True, "Feature flag created successfully."
    except sqlite3.IntegrityError:
        conn.close()
        return False, "Feature key already exists."


def delete_feature_flag(feature_key):
    """Deletes a feature flag."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM feature_flags WHERE feature_key = ?', (feature_key,))
    conn.commit()
    conn.close()
    return True


def is_feature_enabled(feature_key):
    """Checks if a feature flag is enabled."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT is_enabled FROM feature_flags WHERE feature_key = ?', (feature_key,))
    row = cursor.fetchone()
    conn.close()
    return bool(row['is_enabled']) if row else True


def seed_data(conn=None):
    close_conn = False
    if conn is None:
        conn = get_db_connection()
        close_conn = True

    cursor = conn.cursor()
    cursor.execute('DELETE FROM expenses')
    cursor.execute('DELETE FROM budgets')

    for cat, budget in DEFAULT_BUDGETS.items():
        cursor.execute('INSERT INTO budgets (category, monthly_budget) VALUES (?, ?)', (cat, budget))

    # Realistic Indian Rupees (₹ INR) sample spending ranges
    sample_items = {
        "Food & Dining": [
            ("BigBasket / Grocery Store", (1200, 4200)),
            ("Zomato / Swiggy Delivery", (250, 750)),
            ("Restaurant Dinner", (850, 2400)),
            ("Cafe & Chai Point", (120, 380)),
            ("Vegetable & Fruit Mandi", (350, 950)),
            ("Weekend Family Brunch", (1400, 3200))
        ],
        "Transportation": [
            ("Petrol / Fuel Refill", (1000, 2600)),
            ("Metro SmartCard Recharge", (400, 1000)),
            ("Uber / Ola Ride", (180, 650)),
            ("Auto Rickshaw Ride", (70, 220)),
            ("Vehicle Maintenance & Polish", (1500, 4200))
        ],
        "Education": [
            ("Online Course (Udemy/Coursera)", (600, 2800)),
            ("Textbooks & Technical Manuals", (500, 1800)),
            ("Exam Registration Fee", (1500, 4500)),
            ("Educational Tool / Software License", (800, 2400)),
            ("Library & Research Journal Access", (300, 900))
        ],
        "Shopping": [
            ("Amazon / Myntra Apparel", (1200, 4200)),
            ("Electronics & Mobile Accessories", (800, 3800)),
            ("Footwear & Sneakers", (1200, 3200)),
            ("Home Decor & Kitchenware", (700, 2600)),
            ("Personal Care Products", (400, 1500))
        ],
        "Bills & Utilities": [
            ("Electricity Board Bill (BESCOM/Tata)", (1800, 3800)),
            ("High-Speed Fiber WiFi (Jio/Airtel)", (800, 1600)),
            ("Mobile Postpaid / Recharge Plan", (450, 1100)),
            ("LPG Gas Cylinder / Piped Gas", (850, 1150)),
            ("Water Supply & Society Maintenance", (600, 1400))
        ],
        "Entertainment": [
            ("PVR / INOX Cinema & Snacks", (550, 1450)),
            ("Netflix & Prime Subscription", (399, 899)),
            ("Gaming / Steam Purchase", (400, 1800)),
            ("Concert / Cultural Event Pass", (1200, 3500)),
            ("Weekend Bowling / Outing", (700, 1600))
        ],
        "Healthcare": [
            ("Apollo Pharmacy / MedPlus", (350, 1400)),
            ("Doctor Consultation Fee", (500, 1200)),
            ("Diagnostic Blood Tests / Health Check", (900, 2600)),
            ("Vitamins & Protein Supplement", (600, 1600))
        ],
        "Others": [
            ("Wedding / Birthday Gift", (900, 2800)),
            ("Home Hardware & Repairs", (450, 1600)),
            ("Dry Cleaning & Laundry", (300, 900)),
            ("Courier & Speed Post", (120, 350))
        ]
    }

    today = datetime.date.today()
    random.seed(42)

    records = []
    # 180 days history
    for day_offset in range(180, -1, -1):
        current_date = today - datetime.timedelta(days=day_offset)
        num_transactions = random.choices([0, 1, 2, 3], weights=[0.15, 0.45, 0.30, 0.10])[0]

        for _ in range(num_transactions):
            category = random.choice(list(sample_items.keys()))
            item_name, amount_range = random.choice(sample_items[category])
            amount = float(random.randint(amount_range[0], amount_range[1]))
            payment = random.choice(PAYMENT_METHODS)
            date_str = current_date.strftime("%Y-%m-%d")
            records.append((date_str, item_name, category, amount, payment, f"Regular {category.lower()} transaction"))

    # Add realistic outlier spikes in INR
    anom_date_1 = (today - datetime.timedelta(days=40)).strftime("%Y-%m-%d")
    records.append((anom_date_1, "Flagship Laptop Purchase", "Shopping", 64999.00, "Credit Card", "Annual tech hardware upgrade"))

    anom_date_2 = (today - datetime.timedelta(days=80)).strftime("%Y-%m-%d")
    records.append((anom_date_2, "Annual University Professional Certification", "Education", 28500.00, "Net Banking", "One-off career certification fee"))

    cursor.executemany('''
        INSERT INTO expenses (date, title, category, amount, payment_method, notes)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', records)

    conn.commit()
    if close_conn:
        conn.close()


def is_user_admin(user_id):
    """Checks if the given user_id belongs to an administrator account."""
    if not user_id:
        return True
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT role FROM users WHERE id = ?', (user_id,))
        row = cursor.fetchone()
        conn.close()
        return bool(row and row['role'] == 'admin')
    except Exception:
        return True


def get_expenses_df(start_date=None, end_date=None, category=None, user_id=None):
    """Returns expenses as a clean Pandas DataFrame for the specific user_id."""
    conn = get_db_connection()
    query = "SELECT id, date, title, category, amount, payment_method, notes, frequency, user_id FROM expenses WHERE 1=1"
    params = []

    if user_id is not None:
        query += " AND user_id = ?"
        params.append(user_id)
    if start_date:
        query += " AND date >= ?"
        params.append(start_date)
    if end_date:
        query += " AND date <= ?"
        params.append(end_date)
    if category and category != "All":
        query += " AND category = ?"
        params.append(category)

    query += " ORDER BY date DESC, id DESC"

    df = pd.read_sql_query(query, conn, params=params)
    conn.close()

    if not df.empty:
        df['date'] = pd.to_datetime(df['date'])
        df['amount'] = pd.to_numeric(df['amount'], errors='coerce').fillna(0.0)
    else:
        df = pd.DataFrame(columns=['id', 'date', 'title', 'category', 'amount', 'payment_method', 'notes', 'frequency', 'user_id'])
    return df


def get_all_expenses_list(start_date=None, end_date=None, category=None, search=None, user_id=None, frequency=None):
    conn = get_db_connection()
    query = "SELECT id, date, title, category, amount, payment_method, notes, frequency, user_id FROM expenses WHERE 1=1"
    params = []

    if user_id is not None:
        query += " AND user_id = ?"
        params.append(user_id)
    if frequency and frequency != "all":
        query += " AND frequency = ?"
        params.append(frequency)
    if start_date:
        query += " AND date >= ?"
        params.append(start_date)
    if end_date:
        query += " AND date <= ?"
        params.append(end_date)
    if category and category != "All":
        query += " AND category = ?"
        params.append(category)
    if search:
        query += " AND (title LIKE ? OR notes LIKE ?)"
        params.extend([f"%{search}%", f"%{search}%"])

    query += " ORDER BY date DESC, id DESC"

    cursor = conn.cursor()
    cursor.execute(query, params)
    rows = cursor.fetchall()
    conn.close()

    return [dict(row) for row in rows]


def add_expense(date, title, category, amount, payment_method, notes="", frequency="daily", user_id=1):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO expenses (date, title, category, amount, payment_method, notes, frequency, user_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (date, title, category, float(amount), payment_method, notes or "", frequency or "daily", user_id or 1))
    expense_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return expense_id


def update_expense(expense_id, date, title, category, amount, payment_method, notes="", frequency="daily", user_id=1):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        UPDATE expenses
        SET date = ?, title = ?, category = ?, amount = ?, payment_method = ?, notes = ?, frequency = ?, user_id = ?
        WHERE id = ?
    ''', (date, title, category, float(amount), payment_method, notes or "", frequency or "daily", user_id or 1, expense_id))
    conn.commit()
    conn.close()


def delete_expense(expense_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM expenses WHERE id = ?', (expense_id,))
    conn.commit()
    conn.close()


def get_setting(key, default=None):
    """Retrieves a persistent setting value from SQLite by key."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT setting_value FROM settings WHERE setting_key = ?', (key,))
        row = cursor.fetchone()
        conn.close()
        return row['setting_value'] if row else default
    except Exception:
        return default


def set_setting(key, value):
    """Saves or updates a persistent setting value in SQLite."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO settings (setting_key, setting_value)
        VALUES (?, ?)
        ON CONFLICT(setting_key) DO UPDATE SET setting_value = excluded.setting_value
    ''', (key, str(value)))
    conn.commit()
    conn.close()


def get_constant_monthly_budget():
    """Retrieves the user's constant overall monthly budget target from persistent storage."""
    val = get_setting('constant_monthly_budget')
    if val is not None:
        try:
            return float(val)
        except ValueError:
            pass
    
    # Fallback to sum of current category budgets if setting not explicitly set
    budgets = get_budgets()
    if budgets:
        sum_b = float(sum(budgets.values()))
        if sum_b > 0:
            return sum_b
    return 54000.0


def set_constant_monthly_budget(amount):
    """Sets and persists the user's constant overall monthly budget target."""
    set_setting('constant_monthly_budget', float(amount))


def get_budgets():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT category, monthly_budget FROM budgets ORDER BY category ASC')
    rows = cursor.fetchall()
    conn.close()
    return {row['category']: float(row['monthly_budget']) for row in rows}


def update_budget(category, monthly_budget):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO budgets (category, monthly_budget)
        VALUES (?, ?)
        ON CONFLICT(category) DO UPDATE SET monthly_budget = excluded.monthly_budget
    ''', (category, float(monthly_budget)))
    conn.commit()
    conn.close()


def clear_all_expenses(user_id=None):
    """Deletes expense records for the specified user (or all if user_id is None)."""
    conn = get_db_connection()
    cursor = conn.cursor()
    if user_id is not None:
        cursor.execute('DELETE FROM expenses WHERE user_id = ?', (user_id,))
    else:
        cursor.execute('DELETE FROM expenses')
    conn.commit()
    conn.close()
    return True


def get_expenses_count(user_id=None):
    """Returns the total number of transactions for the specified user (or overall total if None)."""
    conn = get_db_connection()
    cursor = conn.cursor()
    if user_id is not None:
        cursor.execute('SELECT COUNT(*) FROM expenses WHERE user_id = ?', (user_id,))
    else:
        cursor.execute('SELECT COUNT(*) FROM expenses')
    count = cursor.fetchone()[0]
    conn.close()
    return count


def bulk_add_expenses(records, replace_existing=False, user_id=1):
    """
    Inserts a list of expense records in bulk.
    records: list of tuples (date, title, category, amount, payment_method, notes)
    """
    if not records:
        return 0

    conn = get_db_connection()
    cursor = conn.cursor()

    if replace_existing:
        if user_id is not None:
            cursor.execute('DELETE FROM expenses WHERE user_id = ?', (user_id,))
        else:
            cursor.execute('DELETE FROM expenses')

    records_with_user = [
        (r[0], r[1], r[2], r[3], r[4], r[5] if len(r) > 5 else "", 'daily', user_id or 1)
        for r in records
    ]

    cursor.executemany('''
        INSERT INTO expenses (date, title, category, amount, payment_method, notes, frequency, user_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', records_with_user)

    # Ensure all imported categories exist in the budgets table
    distinct_cats = set(r[2] for r in records if r[2] and str(r[2]).strip())
    for cat in distinct_cats:
        cursor.execute('''
            INSERT INTO budgets (category, monthly_budget)
            VALUES (?, 0.0)
            ON CONFLICT(category) DO NOTHING
        ''', (cat,))

    conn.commit()
    conn.close()
    return len(records)


def get_distinct_categories():
    """Returns all default standard categories plus any custom categories from user expenses/budgets."""
    cats_set = set(DEFAULT_CATEGORIES)
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT DISTINCT category FROM expenses
            WHERE category IS NOT NULL AND TRIM(category) != ''
        ''')
        for row in cursor.fetchall():
            if row[0] and str(row[0]).strip():
                cats_set.add(str(row[0]).strip())
                
        cursor.execute('''
            SELECT DISTINCT category FROM budgets
            WHERE category IS NOT NULL AND TRIM(category) != ''
        ''')
        for row in cursor.fetchall():
            if row[0] and str(row[0]).strip():
                cats_set.add(str(row[0]).strip())
        conn.close()
    except Exception:
        pass

    return sorted(list(cats_set))


def get_distinct_payment_methods():
    """Returns standard payment methods plus any custom payment methods in user expenses."""
    methods_set = set(PAYMENT_METHODS)
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT DISTINCT payment_method FROM expenses
            WHERE payment_method IS NOT NULL AND TRIM(payment_method) != ''
        ''')
        for row in cursor.fetchall():
            if row[0] and str(row[0]).strip():
                methods_set.add(str(row[0]).strip())
        conn.close()
    except Exception:
        pass

    return sorted(list(methods_set))


def reset_sample_data():
    """Clears all expenses so user can upload their own data."""
    clear_all_expenses()
    return True

