/**
 * Personal Expenses Analysis (PEA) - Interactive Dashboard Logic (Indian Rupees ₹)
 * Handles Chart.js visualizations, AJAX requests, filters, CRUD modals, and toast alerts.
 */

// Global Chart Instances
let categoryChartInstance = null;
let budgetChartInstance = null;
let monthlyChartInstance = null;
let dowChartInstance = null;
let paymentChartInstance = null;

// State
let appCategories = [];
let appPaymentMethods = [];
let currentFilterPeriod = null;

document.addEventListener('DOMContentLoaded', async () => {
  initTabs();
  initMobileNav();
  initProfileListeners();
  initModals();
  initDropzones();
  await loadFilterOptions();
  await refreshDashboard();
  initTransactionsListeners();
  initBudgetListeners();
});

// Helper for Indian Rupee Formatting
function formatINR(amount) {
  if (isNaN(amount) || amount === null) return '₹0.00';
  return '₹' + Number(amount).toLocaleString('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

// ----------------------------------------------------
// Toast Notification
// ----------------------------------------------------
function showToast(message, type = 'success') {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `<i class="fa-solid fa-${type === 'success' ? 'circle-check' : 'circle-exclamation'}"></i> <span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(30px)';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// ----------------------------------------------------
// Tab Navigation & Mobile Drawer Integration
// ----------------------------------------------------
function closeMobileSidebar() {
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('sidebar-overlay');
  if (sidebar) sidebar.classList.remove('open');
  if (overlay) overlay.classList.remove('active');
}

function openMobileSidebar() {
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('sidebar-overlay');
  if (sidebar) sidebar.classList.add('open');
  if (overlay) overlay.classList.add('active');
}

function switchTab(targetTabId) {
  const navButtons = document.querySelectorAll('.nav-item');
  const bottomNavButtons = document.querySelectorAll('.bottom-nav-item:not(.bottom-nav-fab)');
  const tabPanes = document.querySelectorAll('.tab-pane');

  navButtons.forEach(b => {
    b.classList.toggle('active', b.getAttribute('data-tab') === targetTabId);
  });

  bottomNavButtons.forEach(b => {
    b.classList.toggle('active', b.getAttribute('data-tab') === targetTabId);
  });

  tabPanes.forEach(p => {
    p.classList.toggle('active', p.id === targetTabId);
  });

  const tabTitleMap = {
    'tab-overview': 'Personal Expenses Analysis Dashboard (₹)',
    'tab-history': 'Historical Expense Archives & Past Monthly Statements',
    'tab-analytics': 'Deep Financial Analytics & Statistics (INR)',
    'tab-transactions': 'Expense Ledger & Transaction Manager',
    'tab-budgets': 'Monthly Budget Allocation & Variance (₹)',
    'tab-reports': 'One-Click Financial Reports & Data Export',
    'tab-profile': 'User Profile & Account Settings (₹)'
  };
  const titleEl = document.getElementById('page-title');
  if (titleEl) {
    titleEl.textContent = tabTitleMap[targetTabId] || 'Expenses Dashboard';
  }

  // Dismiss mobile drawer upon navigating
  closeMobileSidebar();

  if (targetTabId === 'tab-transactions') {
    loadTransactions();
  } else if (targetTabId === 'tab-budgets') {
    loadBudgets();
  } else if (targetTabId === 'tab-history') {
    loadExpenseHistory();
  } else if (targetTabId === 'tab-profile') {
    loadUserProfile();
  }
}
window.switchTab = switchTab;

function initTabs() {
  const navButtons = document.querySelectorAll('.nav-item');
  navButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetTabId = btn.getAttribute('data-tab');
      if (targetTabId) {
        switchTab(targetTabId);
      }
    });
  });
}

function initMobileNav() {
  const toggleBtn = document.getElementById('mobile-menu-toggle');
  const closeBtn = document.getElementById('sidebar-close-btn');
  const overlay = document.getElementById('sidebar-overlay');
  const fabBtn = document.getElementById('btn-mobile-fab');

  if (toggleBtn) {
    toggleBtn.addEventListener('click', openMobileSidebar);
  }
  if (closeBtn) {
    closeBtn.addEventListener('click', closeMobileSidebar);
  }
  if (overlay) {
    overlay.addEventListener('click', closeMobileSidebar);
  }
  if (fabBtn) {
    fabBtn.addEventListener('click', () => {
      if (typeof openAddExpenseModal === 'function') {
        openAddExpenseModal();
      }
    });
  }

  // Bottom navigation items
  const bottomNavButtons = document.querySelectorAll('.bottom-nav-item:not(.bottom-nav-fab)');
  bottomNavButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetTabId = btn.getAttribute('data-tab');
      if (targetTabId) {
        switchTab(targetTabId);
      }
    });
  });
}

// ----------------------------------------------------
// Filter Options & Period Change
// ----------------------------------------------------
async function loadFilterOptions() {
  try {
    const res = await fetch('/api/filter-options');
    const data = await res.json();

    appCategories = data.categories || [];
    appPaymentMethods = data.payment_methods || [];
    const currentMonthPeriod = data.current_month || new Date().toISOString().slice(0, 7);

    const periodSelect = document.getElementById('filter-period');
    periodSelect.innerHTML = '';

    // Add Current Month first
    const currOpt = document.createElement('option');
    currOpt.value = currentMonthPeriod;
    const currLabelObj = (data.months && data.months.find(m => m.value === currentMonthPeriod));
    const currLabel = currLabelObj ? currLabelObj.label : 'Current Month';
    currOpt.textContent = `📅 ${currLabel} (Current Month)`;
    periodSelect.appendChild(currOpt);

    // Add All Time option
    const allOpt = document.createElement('option');
    allOpt.value = 'all';
    allOpt.textContent = '📁 All Time (Historical Archive)';
    periodSelect.appendChild(allOpt);

    // Add other historical months
    if (data.months && data.months.length > 0) {
      data.months.forEach(m => {
        if (m.value !== currentMonthPeriod) {
          const opt = document.createElement('option');
          opt.value = m.value;
          opt.textContent = `📜 ${m.label} (History Archive)`;
          periodSelect.appendChild(opt);
        }
      });
    }

    // Default filter to Current Month for fresh monthly overview
    if (!currentFilterPeriod) {
      currentFilterPeriod = currentMonthPeriod;
    }

    periodSelect.value = currentFilterPeriod;

    // Re-attach change listener safely
    periodSelect.replaceWith(periodSelect.cloneNode(true));
    const newPeriodSelect = document.getElementById('filter-period');
    if (newPeriodSelect) {
      newPeriodSelect.value = currentFilterPeriod;
      newPeriodSelect.addEventListener('change', (e) => {
        currentFilterPeriod = e.target.value;
        const pdfBtn = document.getElementById('btn-quick-pdf');
        const repPdfBtn = document.getElementById('download-pdf-btn');
        let pdfUrl = '/api/export/pdf';
        if (currentFilterPeriod !== 'all') {
          const [year, month] = currentFilterPeriod.split('-');
          pdfUrl += `?year=${year}&month=${month}`;
        }
        if (pdfBtn) pdfBtn.href = pdfUrl;
        if (repPdfBtn) repPdfBtn.href = pdfUrl;

        refreshDashboard();
      });
    }

    populateCategoryDropdowns();
  } catch (err) {
    console.error("Failed to load filter options", err);
  }
}

function populateCategoryDropdowns() {
  const catSelect = document.getElementById('exp-category');
  const txFilterCat = document.getElementById('tx-filter-cat');
  const paySelect = document.getElementById('exp-payment');
  const quickCatSelect = document.getElementById('quick-category');
  const quickPaySelect = document.getElementById('quick-payment');

  if (catSelect) {
    catSelect.innerHTML = '';
    appCategories.forEach(c => {
      const opt = document.createElement('option');
      opt.value = c;
      opt.textContent = c;
      catSelect.appendChild(opt);
    });
  }

  if (quickCatSelect) {
    quickCatSelect.innerHTML = '';
    appCategories.forEach(c => {
      const opt = document.createElement('option');
      opt.value = c;
      opt.textContent = c;
      quickCatSelect.appendChild(opt);
    });
  }

  if (txFilterCat) {
    txFilterCat.innerHTML = '<option value="All">All Categories</option>';
    appCategories.forEach(c => {
      const opt = document.createElement('option');
      opt.value = c;
      opt.textContent = c;
      txFilterCat.appendChild(opt);
    });
  }

  if (paySelect) {
    paySelect.innerHTML = '';
    appPaymentMethods.forEach(p => {
      const opt = document.createElement('option');
      opt.value = p;
      opt.textContent = p;
      paySelect.appendChild(opt);
    });
  }

  if (quickPaySelect) {
    quickPaySelect.innerHTML = '';
    appPaymentMethods.forEach(p => {
      const opt = document.createElement('option');
      opt.value = p;
      opt.textContent = p;
      quickPaySelect.appendChild(opt);
    });
  }

  const quickDate = document.getElementById('quick-date');
  if (quickDate && !quickDate.value) {
    quickDate.value = new Date().toISOString().split('T')[0];
  }
}

// ----------------------------------------------------
// Refresh Dashboard & Charts
// ----------------------------------------------------
async function refreshDashboard() {
  let query = '';
  if (currentFilterPeriod !== 'all') {
    const [year, month] = currentFilterPeriod.split('-');
    query = `?year=${year}&month=${month}`;
  }

  try {
    const res = await fetch(`/api/summary${query}`);
    const data = await res.json();

    if (data.success) {
      const txCount = data.kpis ? data.kpis.transaction_count : 0;
      updateEmptyState(txCount, data.kpis);
      updateKPICards(data.kpis);
      updateTopExpenses(data.top_expenses);
      updateAnomalies(data.anomalies);
      updateParetoTable(data.categories);
      updateStatsGrid(data.kpis);
    }

    loadCategoryChart(query);
    loadBudgetChart(query);
    loadMonthlyTrendChart();
    loadDowChart(query);
    loadPaymentChart(query);

  } catch (err) {
    console.error("Dashboard refresh error:", err);
  }
}

function updateEmptyState(count, kpis) {
  const emptyBanner = document.getElementById('overview-empty-state');
  const activeBar = document.getElementById('active-dataset-bar');
  const pulseDot = document.getElementById('pulse-dot');
  const statusText = document.getElementById('dataset-status-text');
  const totalDbCount = kpis ? (kpis.total_db_count || 0) : 0;

  if (totalDbCount === 0) {
    if (emptyBanner) emptyBanner.style.display = 'block';
    if (activeBar) activeBar.style.display = 'none';
    if (pulseDot) pulseDot.className = 'pulse-dot empty';
    if (statusText) statusText.innerHTML = 'No data loaded &bull; Please add expenses or upload a spreadsheet';
  } else {
    if (emptyBanner) emptyBanner.style.display = 'none';
    if (activeBar) activeBar.style.display = 'flex';
    if (pulseDot) pulseDot.className = 'pulse-dot';

    if (count === 0) {
      if (statusText) statusText.innerHTML = `<strong>Fresh Month Started</strong> &bull; 0 transactions logged so far for active period`;
    } else {
      if (statusText) statusText.innerHTML = `<strong>${count}</strong> transactions loaded for active period`;
    }

    const countElem = document.getElementById('dataset-count-text');
    const totalElem = document.getElementById('dataset-total-text');
    if (countElem) countElem.textContent = count;
    if (totalElem && kpis) totalElem.textContent = formatINR(kpis.total_spend);
  }
}

function updateKPICards(kpis) {
  if (!kpis) return;
  const setEl = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
  };

  setEl('kpi-total-spend', formatINR(kpis.total_spend));
  setEl('kpi-tx-count', `${kpis.transaction_count} transactions (avg ${formatINR(kpis.avg_spend)})`);
  setEl('kpi-total-budget', formatINR(kpis.total_budget));

  const pct = kpis.budget_used_pct || 0;
  const remaining = kpis.budget_remaining;

  // Card 2: Budget utilization indicator
  const pctElem = document.getElementById('kpi-budget-pct');
  if (pctElem) {
    if (pct > 100) {
      pctElem.innerHTML = `<span style="color: #ef4444; font-weight: 700;">${pct}% utilized (Exceeded)</span>`;
    } else if (pct >= 80) {
      pctElem.innerHTML = `<span style="color: #f97316; font-weight: 700;">${pct}% utilized (Near Target)</span>`;
    } else {
      pctElem.innerHTML = `<span style="color: #10b981; font-weight: 600;">${pct}% utilized</span>`;
    }
  }

  // Card 3: Surplus / Deficit elements
  const remElem = document.getElementById('kpi-budget-remaining');
  const statusElem = document.getElementById('kpi-variance-status');
  const surplusCard = document.getElementById('kpi-card-surplus') || (remElem ? remElem.closest('.card') : null);
  const surplusTitle = document.getElementById('kpi-surplus-title');

  if (remaining < 0 || pct > 100) {
    // 1. BUDGET EXCEEDED -> RED COLOR (#ef4444)
    if (surplusTitle) surplusTitle.textContent = 'Budget Deficit';
    if (remElem) {
      remElem.textContent = `- ${formatINR(Math.abs(remaining))}`;
      remElem.style.color = '#ef4444';
    }
    if (statusElem) {
      statusElem.textContent = 'Budget Exceeded (Deficit)';
      statusElem.style.color = '#ef4444';
    }
    if (surplusCard) {
      surplusCard.style.borderTop = '4px solid #ef4444';
    }
  } else if (pct >= 80) {
    // 2. NEAR BUDGET TARGET -> ORANGE COLOR (#f97316)
    if (surplusTitle) surplusTitle.textContent = 'Available Surplus';
    if (remElem) {
      remElem.textContent = formatINR(remaining);
      remElem.style.color = '#f97316';
    }
    if (statusElem) {
      statusElem.textContent = 'Near Budget Limit (Warning)';
      statusElem.style.color = '#f97316';
    }
    if (surplusCard) {
      surplusCard.style.borderTop = '4px solid #f97316';
    }
  } else {
    // 3. ON TRACK / SURPLUS -> GREEN COLOR (#10b981)
    if (surplusTitle) surplusTitle.textContent = 'Available Surplus';
    if (remElem) {
      remElem.textContent = formatINR(remaining);
      remElem.style.color = '#10b981';
    }
    if (statusElem) {
      statusElem.textContent = 'Surplus / On Track';
      statusElem.style.color = '#10b981';
    }
    if (surplusCard) {
      surplusCard.style.borderTop = '4px solid #10b981';
    }
  }

  setEl('kpi-daily-burn', `${formatINR(kpis.daily_avg_spend)}/day`);
  setEl('kpi-top-category', `Top: ${kpis.top_category} (${formatINR(kpis.top_category_amount)})`);
}

function updateTopExpenses(expenses) {
  const tbody = document.getElementById('top-expenses-body');
  if (!tbody) return;
  if (!expenses || expenses.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted" style="padding: 16px; text-align: center; color: #94a3b8;">No expenses logged for active period.</td></tr>';
    return;
  }

  tbody.innerHTML = expenses.map(e => `
    <tr style="border-bottom: 1px solid #f1f5f9;">
      <td style="padding: 10px;">${e.date}</td>
      <td style="padding: 10px;"><strong>${escapeHtml(e.title)}</strong></td>
      <td style="padding: 10px;"><span class="badge badge-secondary" style="background: #f1f5f9; color: #475569; padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: 600;">${escapeHtml(e.category)}</span></td>
      <td style="padding: 10px; font-weight: 700; color: #0f172a;">${formatINR(e.amount)}</td>
      <td style="padding: 10px; text-align: right;">
        <button onclick="openEditExpenseModal(${e.id})" title="Edit" style="background: none; border: none; color: #2563eb; cursor: pointer; padding: 2px 6px; font-size: 13px;">
          <i class="fa-solid fa-pen"></i>
        </button>
        <button onclick="confirmDeleteExpense(${e.id})" title="Delete" style="background: none; border: none; color: #ef4444; cursor: pointer; padding: 2px 6px; font-size: 13px;">
          <i class="fa-solid fa-trash"></i>
        </button>
      </td>
    </tr>
  `).join('');
}

function updateAnomalies(anomalies) {
  const tbody = document.getElementById('anomaly-table-body');
  const badge = document.getElementById('badge-anomaly-count');
  
  if (badge) badge.textContent = `${anomalies ? anomalies.length : 0} detected`;
  if (!tbody) return;

  if (!anomalies || anomalies.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">No statistical outliers detected (Z-Score &le; 2.0).</td></tr>';
    return;
  }

  tbody.innerHTML = anomalies.slice(0, 6).map(a => `
    <tr>
      <td>${a.date}</td>
      <td><strong>${escapeHtml(a.title)}</strong></td>
      <td><span class="badge badge-secondary">${escapeHtml(a.category)}</span></td>
      <td><strong class="text-amber">${formatINR(a.amount)}</strong></td>
      <td><span class="badge badge-warning">Z: ${a.z_score}σ</span></td>
    </tr>
  `).join('');
}

function updateParetoTable(categories) {
  const tbody = document.getElementById('pareto-table-body');
  if (!tbody) return;
  if (!categories || categories.length === 0) {
    tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted">No category data.</td></tr>';
    return;
  }

  tbody.innerHTML = categories.map(c => {
    let badgeClass = 'badge-success';
    if (c.status === 'Exceeded') badgeClass = 'badge-danger';
    else if (c.status === 'Warning') badgeClass = 'badge-warning';

    return `
      <tr>
        <td><strong>${escapeHtml(c.category)}</strong></td>
        <td>${formatINR(c.total_amount)}</td>
        <td>${c.percentage}%</td>
        <td>${c.cumulative_share}%</td>
        <td>${c.tx_count}</td>
        <td>${formatINR(c.avg_amount)}</td>
        <td>${formatINR(c.max_amount)}</td>
        <td>${formatINR(c.budget)}</td>
        <td>${c.variance >= 0 ? `+${formatINR(c.variance)}` : `-${formatINR(Math.abs(c.variance))}`}</td>
        <td><span class="badge ${badgeClass}">${c.status}</span></td>
      </tr>
    `;
  }).join('');
}

function updateStatsGrid(kpis) {
  if (!kpis) return;
  const setEl = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
  };

  setEl('stat-mean', formatINR(kpis.avg_spend));
  setEl('stat-median', formatINR(kpis.median_spend));
  setEl('stat-std', formatINR(kpis.std_spend));
  setEl('stat-max', formatINR(kpis.max_spend));
}

// ----------------------------------------------------
// Chart.js Visualizations
// ----------------------------------------------------
async function loadCategoryChart(query) {
  try {
    const canvas = document.getElementById('categoryChart');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const res = await fetch(`/api/charts/category${query}`);
    const data = await res.json();

    if (categoryChartInstance) categoryChartInstance.destroy();

    categoryChartInstance = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: data.labels,
        datasets: [{
          data: data.values,
          backgroundColor: data.colors,
          borderWidth: 2,
          borderColor: '#ffffff',
          hoverOffset: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'right',
            labels: { boxWidth: 12, font: { family: 'Plus Jakarta Sans', size: 11, weight: '500' } }
          },
          tooltip: {
            callbacks: {
              label: (context) => {
                const val = context.raw || 0;
                const pct = data.percentages[context.dataIndex] || 0;
                return ` ${context.label}: ${formatINR(val)} (${pct}%)`;
              }
            }
          }
        },
        cutout: '62%'
      }
    });
  } catch (err) {
    console.error("Error loading category chart:", err);
  }
}

async function loadBudgetChart(query) {
  try {
    const canvas = document.getElementById('budgetChart');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const res = await fetch(`/api/charts/budget${query}`);
    const data = await res.json();

    if (budgetChartInstance) budgetChartInstance.destroy();

    budgetChartInstance = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: data.labels,
        datasets: [
          {
            label: 'Actual Spent (₹)',
            data: data.actuals,
            backgroundColor: '#3b82f6',
            borderRadius: 6
          },
          {
            label: 'Monthly Budget (₹)',
            data: data.budgets,
            backgroundColor: '#cbd5e1',
            borderRadius: 6
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: {
            grid: { display: false },
            ticks: { font: { family: 'Plus Jakarta Sans', size: 10 } }
          },
          y: {
            ticks: {
              callback: (val) => '₹' + Number(val).toLocaleString('en-IN'),
              font: { family: 'Plus Jakarta Sans', size: 11 }
            }
          }
        },
        plugins: {
          legend: {
            position: 'top',
            labels: { font: { family: 'Plus Jakarta Sans', size: 12, weight: '600' } }
          }
        }
      }
    });
  } catch (err) {
    console.error("Error loading budget chart:", err);
  }
}

async function loadMonthlyTrendChart() {
  try {
    const canvas = document.getElementById('monthlyChart') || document.getElementById('monthlyTrendChart');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const res = await fetch('/api/charts/monthly');
    const data = await res.json();

    if (monthlyChartInstance) monthlyChartInstance.destroy();

    monthlyChartInstance = new Chart(ctx, {
      type: 'line',
      data: {
        labels: data.labels,
        datasets: [
          {
            label: 'Monthly Spending (₹)',
            data: data.monthly_totals,
            borderColor: '#2563eb',
            backgroundColor: 'rgba(37, 99, 235, 0.08)',
            borderWidth: 2.5,
            fill: true,
            tension: 0.35,
            pointBackgroundColor: '#2563eb',
            pointRadius: 4
          },
          {
            label: '3-Mo Moving Avg (₹)',
            data: data.moving_averages,
            borderColor: '#f59e0b',
            borderWidth: 2,
            borderDash: [5, 5],
            fill: false,
            tension: 0.35,
            pointRadius: 0
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            ticks: {
              callback: (val) => '₹' + Number(val).toLocaleString('en-IN'),
              font: { family: 'Plus Jakarta Sans', size: 11 }
            }
          },
          x: {
            grid: { display: false },
            ticks: { font: { family: 'Plus Jakarta Sans', size: 11 } }
          }
        },
        plugins: {
          legend: {
            position: 'top',
            labels: { font: { family: 'Plus Jakarta Sans', size: 12, weight: '600' } }
          }
        }
      }
    });
  } catch (err) {
    console.error("Error loading monthly trend chart:", err);
  }
}

async function loadDowChart(query) {
  try {
    const canvas = document.getElementById('dowChart');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const res = await fetch(`/api/charts/dow${query}`);
    const data = await res.json();

    if (dowChartInstance) dowChartInstance.destroy();

    dowChartInstance = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: data.days,
        datasets: [{
          label: 'Total Spend (₹)',
          data: data.totals,
          backgroundColor: '#10b981',
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            ticks: {
              callback: (val) => '₹' + Number(val).toLocaleString('en-IN'),
              font: { family: 'Plus Jakarta Sans', size: 11 }
            }
          },
          x: {
            grid: { display: false },
            ticks: { font: { family: 'Plus Jakarta Sans', size: 11 } }
          }
        },
        plugins: {
          legend: { display: false }
        }
      }
    });
  } catch (err) {
    console.error("Error loading dow chart:", err);
  }
}

async function loadPaymentChart(query) {
  try {
    const canvas = document.getElementById('paymentChart');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const res = await fetch(`/api/charts/payment${query}`);
    const data = await res.json();

    if (paymentChartInstance) paymentChartInstance.destroy();

    paymentChartInstance = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: data.labels,
        datasets: [{
          data: data.values,
          backgroundColor: ['#6366f1', '#3b82f6', '#10b981', '#f59e0b', '#ec4899'],
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'right',
            labels: { font: { family: 'Plus Jakarta Sans', size: 11, weight: '500' } }
          }
        }
      }
    });
  } catch (err) {
    console.error("Error loading payment chart:", err);
  }
}

// ----------------------------------------------------
// Transactions Management (CRUD)
// ----------------------------------------------------
let allExpensesCache = [];

async function loadTransactions() {
  const tbody = document.getElementById('transactions-table-body');
  if (tbody) {
    tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted" style="padding: 20px; text-align: center;">Loading transaction ledger...</td></tr>';
  }

  try {
    const res = await fetch('/api/expenses');
    const data = await res.json();

    if (data.success) {
      allExpensesCache = data.expenses || [];
      renderFilteredTransactions();
    } else {
      if (tbody) {
        tbody.innerHTML = `<tr><td colspan="7" class="text-center text-muted" style="padding: 20px; text-align: center; color: #ef4444;">${data.error || 'Failed to load transactions.'}</td></tr>`;
      }
    }
  } catch (err) {
    console.error("Error loading transactions:", err);
    if (tbody) {
      tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted" style="padding: 20px; text-align: center; color: #ef4444;">Error loading transactions. Please refresh.</td></tr>';
    }
  }
}

function renderFilteredTransactions() {
  const tbody = document.getElementById('transactions-table-body');
  if (!tbody) return;

  const countSpan = document.getElementById('tx-showing-count');
  const searchInput = document.getElementById('tx-search-input');
  const catFilter = document.getElementById('tx-filter-cat');

  const search = searchInput ? searchInput.value.toLowerCase().trim() : '';
  const selectedCat = catFilter ? catFilter.value : 'All';

  const filtered = allExpensesCache.filter(item => {
    const matchSearch = !search || 
      (item.title && item.title.toLowerCase().includes(search)) || 
      (item.notes && item.notes.toLowerCase().includes(search));
    const matchCat = (selectedCat === 'All') || (item.category === selectedCat);
    return matchSearch && matchCat;
  });

  if (countSpan) {
    countSpan.textContent = `Showing ${filtered.length} of ${allExpensesCache.length} transactions`;
  }

  if (filtered.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted" style="padding: 20px; text-align: center; color: #94a3b8;">No matching transactions found.</td></tr>';
    return;
  }

  tbody.innerHTML = filtered.slice(0, 100).map(item => `
    <tr style="border-bottom: 1px solid #f1f5f9;">
      <td style="padding: 10px; font-weight: 600; color: #475569;">${item.date}</td>
      <td style="padding: 10px;"><strong>${escapeHtml(item.title)}</strong></td>
      <td style="padding: 10px;"><span class="badge badge-secondary" style="background: #f1f5f9; color: #475569; padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: 600;">${escapeHtml(item.category)}</span></td>
      <td style="padding: 10px; color: #334155;">${escapeHtml(item.payment_method || 'UPI')}</td>
      <td style="padding: 10px;"><span style="background: #f0fdf4; color: #166534; padding: 2px 6px; border-radius: 4px; font-size: 11px; font-weight: 600;">${escapeHtml(item.frequency || 'daily')}</span></td>
      <td style="padding: 10px; font-weight: 800; color: #0f172a;">${formatINR(item.amount)}</td>
      <td style="padding: 10px; text-align: right;">
        <button class="action-btn edit-btn" onclick="openEditExpenseModal(${item.id})" title="Edit Transaction" style="background: none; border: none; color: #2563eb; cursor: pointer; padding: 2px 6px; font-size: 13px;">
          <i class="fa-solid fa-pen-to-square"></i>
        </button>
        <button class="action-btn delete-btn" onclick="confirmDeleteExpense(${item.id})" title="Delete Transaction" style="background: none; border: none; color: #ef4444; cursor: pointer; padding: 2px 6px; font-size: 13px;">
          <i class="fa-solid fa-trash-can"></i>
        </button>
      </td>
    </tr>
  `).join('');
}

function initTransactionsListeners() {
  const searchInput = document.getElementById('tx-search-input');
  const catFilter = document.getElementById('tx-filter-cat');

  searchInput.addEventListener('input', renderFilteredTransactions);
  catFilter.addEventListener('change', renderFilteredTransactions);

  document.getElementById('btn-add-tx-direct').addEventListener('click', () => {
    openAddExpenseModal();
  });
}

window.openAddExpenseModal = function() {
  populateCategoryDropdowns();
  const titleElem = document.getElementById('modal-expense-title') || document.getElementById('modal-title');
  if (titleElem) titleElem.textContent = 'Add New Expense (₹)';
  
  const idElem = document.getElementById('exp-id');
  if (idElem) idElem.value = '';
  const dateElem = document.getElementById('exp-date');
  if (dateElem) dateElem.value = new Date().toISOString().split('T')[0];
  const titleInp = document.getElementById('exp-title');
  if (titleInp) titleInp.value = '';
  const amountElem = document.getElementById('exp-amount');
  if (amountElem) amountElem.value = '';
  const notesElem = document.getElementById('exp-notes');
  if (notesElem) notesElem.value = '';

  const modal = document.getElementById('modal-expense');
  if (modal) {
    modal.classList.add('active');
    modal.style.display = 'flex';
  }
};

window.openEditExpenseModal = function(id) {
  const expense = allExpensesCache.find(e => e.id === id);
  if (!expense) return;

  const titleElem = document.getElementById('modal-expense-title') || document.getElementById('modal-title');
  if (titleElem) titleElem.textContent = 'Edit Expense (₹)';

  const idElem = document.getElementById('exp-id');
  if (idElem) idElem.value = expense.id;
  const dateElem = document.getElementById('exp-date');
  if (dateElem) dateElem.value = expense.date;
  const titleInp = document.getElementById('exp-title');
  if (titleInp) titleInp.value = expense.title;
  const amountElem = document.getElementById('exp-amount');
  if (amountElem) amountElem.value = expense.amount;
  const catElem = document.getElementById('exp-category');
  if (catElem) catElem.value = expense.category;
  const payElem = document.getElementById('exp-payment');
  if (payElem) payElem.value = expense.payment_method;
  const freqElem = document.getElementById('exp-frequency');
  if (freqElem) freqElem.value = expense.frequency || 'daily';
  const notesElem = document.getElementById('exp-notes');
  if (notesElem) notesElem.value = expense.notes || '';

  const modal = document.getElementById('modal-expense');
  if (modal) modal.classList.add('active');
};

window.confirmDeleteExpense = async function(id) {
  if (!confirm(`Are you sure you want to delete expense record #${id}?`)) return;

  try {
    const res = await fetch(`/api/expenses/${id}`, { method: 'DELETE' });
    const data = await res.json();
    if (data.success) {
      showToast('Expense deleted successfully.');
      loadTransactions();
      refreshDashboard();
    } else {
      showToast(data.error || 'Failed to delete expense', 'error');
    }
  } catch (err) {
    showToast('Failed to delete expense', 'error');
  }
};

// ----------------------------------------------------
// Budget Planner
// ----------------------------------------------------
let currentBudgets = {};

async function loadBudgets() {
  const container = document.getElementById('budget-cards-container');
  if (container) container.innerHTML = '<p class="text-muted">Loading budgets...</p>';

  let query = '';
  if (currentFilterPeriod && currentFilterPeriod !== 'all') {
    const [year, month] = currentFilterPeriod.split('-');
    query = `?year=${year}&month=${month}`;
  }

  try {
    const [bRes, sRes] = await Promise.all([
      fetch('/api/budgets'),
      fetch(`/api/summary${query}`)
    ]);
    const bData = await bRes.json();
    const sData = await sRes.json();

    currentBudgets = bData.budgets || {};
    const bvaList = sData.budget_vs_actual || [];

    const bvaMap = {};
    bvaList.forEach(item => { bvaMap[item.category] = item; });

    const constantMonthlyTarget = bData.constant_monthly_budget || Object.values(currentBudgets).reduce((a, b) => a + b, 0);
    const constInput = document.getElementById('input-constant-budget');
    const modalInput = document.getElementById('modal-constant-budget-input');
    if (constInput) constInput.value = Math.round(constantMonthlyTarget);
    if (modalInput) modalInput.value = Math.round(constantMonthlyTarget);

    if (container) {
      container.innerHTML = Object.entries(currentBudgets).map(([cat, budgetVal]) => {
        const actualItem = bvaMap[cat] || { actual: 0, pct_used: 0 };
        const actual = actualItem.actual;
        const pct = budgetVal > 0 ? Math.round((actual / budgetVal) * 100) : 0;

        let barColor = '#10b981';
        let statusBadge = '<span class="badge badge-success">On Track</span>';
        if (pct > 100) {
          barColor = '#ef4444';
          statusBadge = '<span class="badge badge-danger">Budget Exceeded</span>';
        } else if (pct >= 80) {
          barColor = '#f97316';
          statusBadge = '<span class="badge badge-warning">Near Target</span>';
        }

        return `
          <div class="budget-card" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px; box-shadow: 0 1px 4px rgba(0,0,0,0.03);">
            <div class="budget-card-top" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
              <span class="budget-cat-name" style="font-weight: 700; color: #0f172a; font-size: 14px;">${escapeHtml(cat)}</span>
              ${statusBadge}
            </div>
            <div class="budget-input-row" style="display: flex; align-items: center; gap: 6px; margin-bottom: 10px;">
              <span style="font-weight: 700; color: #64748b;">₹</span>
              <input type="number" step="500" min="0" class="budget-val-input" data-category="${escapeHtml(cat)}" value="${budgetVal}" style="flex: 1; padding: 6px 10px; border: 1px solid #cbd5e1; border-radius: 6px; font-weight: 700; font-size: 14px; outline: none;">
              <button type="button" onclick="saveCategoryBudgets(event)" title="Save Category Budget" style="background: #eff6ff; color: #2563eb; border: 1px solid #bfdbfe; border-radius: 6px; padding: 6px 10px; font-size: 12px; font-weight: 700; cursor: pointer;">
                <i class="fa-solid fa-check"></i> Save
              </button>
            </div>
            <div class="budget-bar-container" style="background: #f1f5f9; border-radius: 4px; height: 8px; overflow: hidden; margin-bottom: 8px;">
              <div class="budget-bar-fill" style="width: ${Math.min(pct, 100)}%; height: 100%; background-color: ${barColor}; transition: width 0.3s ease;"></div>
            </div>
            <div class="budget-card-meta" style="display: flex; justify-content: space-between; font-size: 12px; color: #64748b;">
              <span>Spent: <strong>${formatINR(actual)}</strong></span>
              <span><strong>${pct}%</strong> used</span>
            </div>
          </div>
        `;
      }).join('');

      // Auto-save on input change & Enter key
      document.querySelectorAll('.budget-val-input').forEach(input => {
        input.addEventListener('change', (e) => {
          saveCategoryBudgets(e);
        });
        input.addEventListener('keydown', (e) => {
          if (e.key === 'Enter') {
            e.preventDefault();
            saveCategoryBudgets(e);
          }
        });
      });
    }

  } catch (err) {
    console.error("Error loading budgets:", err);
  }
}

window.saveCategoryBudgets = async function(e) {
  if (e && e.preventDefault) e.preventDefault();
  const inputs = document.querySelectorAll('.budget-val-input');
  const updatedBudgets = {};
  inputs.forEach(input => {
    const cat = input.getAttribute('data-category');
    if (cat) {
      updatedBudgets[cat] = parseFloat(input.value) || 0;
    }
  });

  try {
    const res = await fetch('/api/budgets', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updatedBudgets)
    });
    const data = await res.json();
    if (data.success) {
      showToast(data.message || 'Category budgets updated successfully.');
      await loadBudgets();
      await refreshDashboard();
    } else {
      showToast(data.error || 'Failed to save category budgets', 'error');
    }
  } catch (err) {
    showToast('Error saving budgets', 'error');
  }
};

async function saveConstantBudget(totalAmount) {
  if (isNaN(totalAmount) || totalAmount <= 0) {
    showToast('Please enter a valid positive monthly budget amount.', 'error');
    return;
  }
  try {
    const res = await fetch('/api/budgets/constant', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ total_monthly_budget: totalAmount })
    });
    const data = await res.json();
    if (data.success) {
      showToast(data.message, 'success');
      closeConstantBudgetModal();
      await loadBudgets();
      await refreshDashboard();
    } else {
      showToast(data.error || 'Failed to set constant budget', 'error');
    }
  } catch (err) {
    showToast('Error setting constant budget', 'error');
  }
}

window.openConstantBudgetModal = async function() {
  try {
    const res = await fetch('/api/budgets');
    const data = await res.json();
    if (data.constant_monthly_budget) {
      const modalInput = document.getElementById('modal-constant-budget-input');
      if (modalInput) modalInput.value = Math.round(data.constant_monthly_budget);
    }
  } catch(e) {}
  const modal = document.getElementById('modal-constant-budget');
  if (modal) {
    modal.classList.add('active');
    modal.style.display = 'flex';
  }
};

window.closeConstantBudgetModal = function() {
  const modal = document.getElementById('modal-constant-budget');
  if (modal) {
    modal.classList.remove('active');
    modal.style.display = 'none';
  }
};

function initBudgetListeners() {
  // Save Category Limits form submit
  const formCategoryBudgets = document.getElementById('form-category-budgets');
  const saveCategoryBudgetsHandler = async (e) => {
    if (e) e.preventDefault();
    const inputs = document.querySelectorAll('.budget-val-input');
    const updatedBudgets = {};
    inputs.forEach(input => {
      const cat = input.getAttribute('data-category');
      updatedBudgets[cat] = parseFloat(input.value) || 0;
    });

    try {
      const res = await fetch('/api/budgets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedBudgets)
      });
      const data = await res.json();
      if (data.success) {
        showToast(data.message || 'Category budgets updated successfully.');
        await loadBudgets();
        await refreshDashboard();
      } else {
        showToast(data.error || 'Failed to save category budgets', 'error');
      }
    } catch (err) {
      showToast('Error saving budgets', 'error');
    }
  };

  if (formCategoryBudgets) {
    formCategoryBudgets.addEventListener('submit', saveCategoryBudgetsHandler);
  }
  document.getElementById('btn-save-budgets')?.addEventListener('click', saveCategoryBudgetsHandler);

  // Tab 3 Constant Budget form submit
  const formTabConstant = document.getElementById('form-tab-constant-budget');
  const saveTabConstantHandler = (e) => {
    if (e) e.preventDefault();
    const inputElem = document.getElementById('input-constant-budget');
    if (inputElem) {
      const val = parseFloat(inputElem.value);
      saveConstantBudget(val);
    }
  };

  if (formTabConstant) {
    formTabConstant.addEventListener('submit', saveTabConstantHandler);
  }
  document.getElementById('btn-apply-constant-budget')?.addEventListener('click', saveTabConstantHandler);

  // Overview Quick Edit Budget Trigger
  document.getElementById('btn-quick-edit-budget')?.addEventListener('click', () => {
    openConstantBudgetModal();
  });

  // Preset Buttons in Modal
  document.querySelectorAll('.preset-modal-budget-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const val = parseFloat(btn.getAttribute('data-val'));
      const input = document.getElementById('modal-constant-budget-input');
      if (input) input.value = val;
      if (val > 0) saveConstantBudget(val);
    });
  });

  // Modal Form Submit
  document.getElementById('form-constant-budget')?.addEventListener('submit', (e) => {
    e.preventDefault();
    const val = parseFloat(document.getElementById('modal-constant-budget-input').value);
    saveConstantBudget(val);
  });
}

// ----------------------------------------------------
// Modals, Dropzones & File Uploads
// ----------------------------------------------------
function initModals() {
  const expenseModal = document.getElementById('modal-expense');
  const importModal = document.getElementById('modal-import');

  // Expense modal triggers
  const btnAdd = document.getElementById('btn-open-add-modal');
  if (btnAdd) btnAdd.addEventListener('click', openAddExpenseModal);
  const btnDirectAdd = document.getElementById('btn-add-tx-direct');
  if (btnDirectAdd) btnDirectAdd.addEventListener('click', openAddExpenseModal);

  const modalClose = document.getElementById('modal-close-btn');
  if (modalClose) modalClose.addEventListener('click', () => expenseModal.classList.remove('active'));
  const modalCancel = document.getElementById('modal-cancel-btn');
  if (modalCancel) modalCancel.addEventListener('click', () => expenseModal.classList.remove('active'));

  // Upload modal triggers
  const openUploadModal = () => {
    if (importModal) {
      importModal.classList.add('active');
      const fileInput = document.getElementById('import-file');
      if (fileInput) fileInput.value = '';
      const label = document.getElementById('modal-file-label');
      if (label) label.textContent = 'Click or drag file here to upload';
    }
  };

  const uploadButtons = ['btn-top-upload', 'btn-sidebar-upload', 'btn-reupload', 'btn-import-csv-modal'];
  uploadButtons.forEach(btnId => {
    const el = document.getElementById(btnId);
    if (el) el.addEventListener('click', openUploadModal);
  });

  const importClose = document.getElementById('import-close-btn');
  if (importClose) importClose.addEventListener('click', () => importModal.classList.remove('active'));
  const importCancel = document.getElementById('import-cancel-btn');
  if (importCancel) importCancel.addEventListener('click', () => importModal.classList.remove('active'));

  // Clear data triggers
  const clearButtons = ['btn-clear-all', 'btn-clear-overview', 'btn-clear-tx'];
  clearButtons.forEach(btnId => {
    const el = document.getElementById(btnId);
    if (el) el.addEventListener('click', handleClearAllData);
  });

  // Load sample template trigger
  const btnSample = document.getElementById('btn-load-sample-template');
  if (btnSample) btnSample.addEventListener('click', handleLoadSampleData);

  // Expense form submit
  const formExpense = document.getElementById('form-expense');
  if (formExpense) {
    formExpense.addEventListener('submit', async (e) => {
      e.preventDefault();
      const id = document.getElementById('exp-id').value;
      const dateVal = document.getElementById('exp-date').value;
      const payload = {
        date: dateVal,
        title: document.getElementById('exp-title').value.trim(),
        amount: parseFloat(document.getElementById('exp-amount').value),
        category: document.getElementById('exp-category').value,
        payment_method: document.getElementById('exp-payment').value,
        notes: document.getElementById('exp-notes')?.value?.trim() || '',
        frequency: document.getElementById('exp-frequency')?.value || 'daily'
      };

      const isEdit = !!id;
      const url = isEdit ? `/api/expenses/${id}` : '/api/expenses';
      const method = isEdit ? 'PUT' : 'POST';

      try {
        const res = await fetch(url, {
          method: method,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        const data = await res.json();

        if (data.success) {
          showToast(isEdit ? 'Expense updated successfully.' : 'Expense added successfully.');
          expenseModal.classList.remove('active');
          if (dateVal && dateVal.length >= 7) {
            currentFilterPeriod = dateVal.slice(0, 7);
          }
          await loadFilterOptions();
          await refreshDashboard();
          if (typeof loadTransactions === 'function') loadTransactions();
        } else {
          showToast(data.error || 'Failed to save expense', 'error');
        }
      } catch (err) {
        showToast('Server communication error', 'error');
      }
    });
  }

  // Import form submit
  const formImport = document.getElementById('form-import');
  if (formImport) {
    formImport.addEventListener('submit', async (e) => {
      e.preventDefault();
      const fileInput = document.getElementById('import-file');
      if (!fileInput.files || !fileInput.files[0]) {
        showToast('Please select a CSV or Excel file to upload.', 'error');
        return;
      }
      const replaceBox = document.getElementById('import-replace');
      const replaceExisting = replaceBox ? replaceBox.checked : true;
      await uploadSpreadsheetFile(fileInput.files[0], replaceExisting);
    });
  }
}

// ----------------------------------------------------
// File Upload & Data Actions
// ----------------------------------------------------
async function uploadSpreadsheetFile(file, replaceExisting = true) {
  if (!file) return;

  const validExts = ['.csv', '.xlsx', '.xls'];
  const fileName = file.name.toLowerCase();
  const hasValidExt = validExts.some(ext => fileName.endsWith(ext));
  if (!hasValidExt) {
    showToast('Please upload a .csv, .xlsx, or .xls file.', 'error');
    return;
  }

  const formData = new FormData();
  formData.append('file', file);
  formData.append('replace_existing', replaceExisting ? 'true' : 'false');

  const submitBtn = document.getElementById('import-submit-btn');
  if (submitBtn) {
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processing Data...';
  }

  showToast(`Parsing ${file.name}...`, 'success');

  try {
    const res = await fetch('/api/upload-data', {
      method: 'POST',
      body: formData
    });
    const data = await res.json();

    if (data.success) {
      showToast(data.message, 'success');
      const importModal = document.getElementById('modal-import');
      if (importModal) importModal.classList.remove('active');

      const fileInput = document.getElementById('import-file');
      if (fileInput) fileInput.value = '';
      const label = document.getElementById('modal-file-label');
      if (label) label.textContent = 'Click or drag file here to upload';

      await loadFilterOptions();
      await refreshDashboard();
      loadTransactions();
    } else {
      showToast(data.error || 'Failed to process spreadsheet', 'error');
    }
  } catch (err) {
    showToast('Error uploading file: ' + err.message, 'error');
  } finally {
    if (submitBtn) {
      submitBtn.disabled = false;
      submitBtn.innerHTML = '<i class="fa-solid fa-upload"></i> Process & Load Data';
    }
  }
}

async function handleClearAllData() {
  if (!confirm('Are you sure you want to clear all expense records from the dashboard? This will remove current data and reset the dashboard so you can upload a new dataset.')) {
    return;
  }
  try {
    const res = await fetch('/api/clear-data', { method: 'POST' });
    const data = await res.json();
    if (data.success) {
      showToast('All expense data cleared. Ready for your upload.');
      await loadFilterOptions();
      await refreshDashboard();
      loadTransactions();
    } else {
      showToast(data.error || 'Failed to clear data', 'error');
    }
  } catch (err) {
    showToast('Error clearing data', 'error');
  }
}

async function handleLoadSampleData() {
  try {
    showToast('Loading sample template dataset...');
    const res = await fetch('/api/load-sample-template', { method: 'POST' });
    const data = await res.json();
    if (data.success) {
      showToast(data.message, 'success');
      await loadFilterOptions();
      await refreshDashboard();
      loadTransactions();
    } else {
      showToast(data.error || 'Failed to load sample dataset', 'error');
    }
  } catch (err) {
    showToast('Error loading sample data', 'error');
  }
}

function initDropzones() {
  // Overview dropzone
  const overviewDropzone = document.getElementById('overview-dropzone');
  const overviewInput = document.getElementById('overview-file-input');

  if (overviewDropzone && overviewInput) {
    overviewDropzone.addEventListener('click', (e) => {
      if (e.target !== overviewInput && e.target.tagName !== 'LABEL') {
        overviewInput.click();
      }
    });

    overviewInput.addEventListener('change', () => {
      if (overviewInput.files && overviewInput.files[0]) {
        uploadSpreadsheetFile(overviewInput.files[0], true);
      }
    });

    ['dragenter', 'dragover'].forEach(eventName => {
      overviewDropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        e.stopPropagation();
        overviewDropzone.classList.add('dragover');
      });
    });

    ['dragleave', 'drop'].forEach(eventName => {
      overviewDropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        e.stopPropagation();
        overviewDropzone.classList.remove('dragover');
      });
    });

    overviewDropzone.addEventListener('drop', (e) => {
      const dt = e.dataTransfer;
      if (dt && dt.files && dt.files[0]) {
        uploadSpreadsheetFile(dt.files[0], true);
      }
    });
  }

  // Modal dropzone
  const modalDropzone = document.getElementById('modal-dropzone');
  const modalFileInput = document.getElementById('import-file');
  const modalFileLabel = document.getElementById('modal-file-label');

  if (modalDropzone && modalFileInput) {
    modalDropzone.addEventListener('click', (e) => {
      if (e.target !== modalFileInput && e.target.tagName !== 'LABEL') {
        modalFileInput.click();
      }
    });

    modalFileInput.addEventListener('change', () => {
      if (modalFileInput.files && modalFileInput.files[0]) {
        if (modalFileLabel) modalFileLabel.textContent = `Selected: ${modalFileInput.files[0].name}`;
      }
    });

    ['dragenter', 'dragover'].forEach(eventName => {
      modalDropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        e.stopPropagation();
        modalDropzone.classList.add('dragover');
      });
    });

    ['dragleave', 'drop'].forEach(eventName => {
      modalDropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        e.stopPropagation();
        modalDropzone.classList.remove('dragover');
      });
    });

    modalDropzone.addEventListener('drop', (e) => {
      const dt = e.dataTransfer;
      if (dt && dt.files && dt.files[0]) {
        modalFileInput.files = dt.files;
        if (modalFileLabel) modalFileLabel.textContent = `Selected: ${dt.files[0].name}`;
      }
    });
  }
}

// ----------------------------------------------------
// Manual Expense Entry Handlers
// ----------------------------------------------------

// Quick Inline Form Submit
document.getElementById('quick-manual-form')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  const dateVal = document.getElementById('quick-date')?.value || new Date().toISOString().split('T')[0];
  const titleVal = document.getElementById('quick-title')?.value.trim();
  const amountVal = parseFloat(document.getElementById('quick-amount')?.value);
  const catVal = document.getElementById('quick-category')?.value || 'Others';
  const payVal = document.getElementById('quick-payment')?.value || 'UPI (GPay / PhonePe / Paytm)';

  if (!titleVal || isNaN(amountVal) || amountVal <= 0) {
    showToast('Please enter a valid description and positive amount.', 'error');
    return;
  }

  const payload = {
    date: dateVal,
    title: titleVal,
    amount: amountVal,
    category: catVal,
    payment_method: payVal,
    frequency: 'daily',
    notes: ''
  };

  try {
    const res = await fetch('/api/expenses', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data.success) {
      showToast('Expense added successfully!');
      if (document.getElementById('quick-title')) document.getElementById('quick-title').value = '';
      if (document.getElementById('quick-amount')) document.getElementById('quick-amount').value = '';
      if (dateVal && dateVal.length >= 7) {
        currentFilterPeriod = dateVal.slice(0, 7);
      }
      await loadFilterOptions();
      await refreshDashboard();
      if (typeof loadTransactions === 'function') loadTransactions();
    } else {
      showToast(data.error || 'Failed to add expense', 'error');
    }
  } catch (err) {
    showToast('Failed to communicate with server', 'error');
  }
});

// Empty State Triggers
document.getElementById('btn-empty-manual-add')?.addEventListener('click', () => {
  openAddExpenseModal();
});

document.getElementById('btn-empty-bulk-manual')?.addEventListener('click', () => {
  openBulkManualModal();
});

document.getElementById('btn-open-bulk-manual-bar')?.addEventListener('click', () => {
  openBulkManualModal();
});

// Bulk Manual Entry Modal Logic
window.openBulkManualModal = function() {
  populateCategoryDropdowns();
  const modal = document.getElementById('modal-bulk-manual');
  if (!modal) return;
  const tbody = document.getElementById('tbody-bulk-manual');
  tbody.innerHTML = '';
  addBulkManualRow();
  addBulkManualRow();
  addBulkManualRow();
  modal.classList.add('active');
};

window.closeBulkManualModal = function() {
  const modal = document.getElementById('modal-bulk-manual');
  if (modal) modal.classList.remove('active');
};

function addBulkManualRow() {
  const tbody = document.getElementById('tbody-bulk-manual');
  if (!tbody) return;

  const todayStr = new Date().toISOString().split('T')[0];
  const tr = document.createElement('tr');

  const catOptions = (appCategories.length > 0 ? appCategories : ["Food & Dining", "Transportation", "Bills & Utilities", "Shopping", "Entertainment", "Healthcare", "Others"]).map(c => `<option value="${c}">${c}</option>`).join('');
  const payOptions = (appPaymentMethods.length > 0 ? appPaymentMethods : ["UPI (GPay / PhonePe / Paytm)", "Credit Card", "Debit Card", "Net Banking", "Cash"]).map(p => `<option value="${p}">${p}</option>`).join('');

  tr.innerHTML = `
    <td><input type="date" class="form-control manual-date" value="${todayStr}" style="padding:4px 6px; font-size:12px;"></td>
    <td><input type="text" class="form-control manual-title" placeholder="Item name / Merchant" required style="padding:4px 6px; font-size:12px;"></td>
    <td><input type="number" step="1" min="1" class="form-control manual-amount" placeholder="Amount ₹" required style="padding:4px 6px; font-size:12px;"></td>
    <td><select class="form-control manual-cat" style="padding:4px 6px; font-size:12px;">${catOptions}</select></td>
    <td><select class="form-control manual-pay" style="padding:4px 6px; font-size:12px;">${payOptions}</select></td>
    <td>
      <select class="form-control manual-freq" style="padding:4px 6px; font-size:12px;">
        <option value="daily" selected>Daily</option>
        <option value="monthly">Monthly</option>
      </select>
    </td>
    <td class="text-center">
      <button type="button" class="action-btn delete-btn" onclick="this.closest('tr').remove(); updateBulkManualRowCount();" title="Remove Row">
        <i class="fa-solid fa-trash-can"></i>
      </button>
    </td>
  `;

  tbody.appendChild(tr);
  updateBulkManualRowCount();
}

function updateBulkManualRowCount() {
  const tbody = document.getElementById('tbody-bulk-manual');
  const countSpan = document.getElementById('bulk-manual-count');
  if (tbody && countSpan) {
    const rows = tbody.querySelectorAll('tr').length;
    countSpan.textContent = `${rows} ${rows === 1 ? 'row' : 'rows'}`;
  }
}

document.getElementById('btn-add-manual-row')?.addEventListener('click', addBulkManualRow);

document.getElementById('form-bulk-manual')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  const tbody = document.getElementById('tbody-bulk-manual');
  const trs = tbody.querySelectorAll('tr');
  const items = [];

  trs.forEach(tr => {
    const title = tr.querySelector('.manual-title').value.trim();
    const amount = parseFloat(tr.querySelector('.manual-amount').value);
    if (title && amount > 0) {
      items.push({
        date: tr.querySelector('.manual-date').value,
        title: title,
        amount: amount,
        category: tr.querySelector('.manual-cat').value,
        payment_method: tr.querySelector('.manual-pay').value,
        frequency: tr.querySelector('.manual-freq').value,
        notes: ''
      });
    }
  });

  if (items.length === 0) {
    showToast('Please enter at least one valid manual expense with a positive amount.', 'error');
    return;
  }

  try {
    const res = await fetch('/api/expenses/bulk-manual', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items: items })
    });
    const data = await res.json();
    if (data.success) {
      showToast(data.message || `Saved ${data.count} manual expenses.`);
      closeBulkManualModal();
      await loadFilterOptions();
      await refreshDashboard();
      loadTransactions();
    } else {
      showToast(data.error || 'Failed to save bulk manual expenses', 'error');
    }
  } catch (err) {
    showToast('Server communication error', 'error');
  }
});

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}

// ----------------------------------------------------
// Expense History Archive & Past Monthly Statements
// ----------------------------------------------------
async function loadExpenseHistory() {
  const cardsContainer = document.getElementById('history-cards-container');
  const monthSelect = document.getElementById('history-month-select');
  const searchInput = document.getElementById('history-search-input');
  const tableBody = document.getElementById('history-table-body');
  const countText = document.getElementById('history-showing-count');

  if (cardsContainer) cardsContainer.innerHTML = '<p class="text-muted">Loading historical monthly archives...</p>';

  try {
    const res = await fetch('/api/history');
    const data = await res.json();
    const historyList = data.history || [];

    // Populate historical monthly cards grid
    if (cardsContainer) {
      if (historyList.length === 0) {
        cardsContainer.innerHTML = '<p class="text-muted" style="grid-column: 1/-1;">No historical expense archives found.</p>';
      } else {
        cardsContainer.innerHTML = historyList.map(h => {
          const badgeClass = h.pct_used > 100 ? 'badge-danger' : (h.pct_used >= 80 ? 'badge-warning' : 'badge-success');
          const badgeLabel = h.pct_used > 100 ? 'Budget Exceeded' : (h.pct_used >= 80 ? 'Near Target' : 'On Track');
          const isCurrTag = h.is_current ? '<span class="badge badge-info" style="margin-left: 6px;">Active Month</span>' : '<span class="badge badge-subtle" style="margin-left: 6px;">Archived</span>';

          return `
            <div class="budget-card" style="border-top: 3px solid ${h.is_current ? '#0284c7' : '#8b5cf6'};">
              <div class="budget-card-top" style="align-items: center; justify-content: space-between; display: flex; width: 100%;">
                <strong style="font-size: 15px; color: #1e293b;">${h.label}</strong>
                <div>
                  <span class="badge ${badgeClass}">${badgeLabel}</span>
                  ${isCurrTag}
                </div>
              </div>
              <div style="margin: 10px 0;">
                <div style="font-size: 20px; font-weight: 800; color: #0f172a;">${formatINR(h.total_spend)}</div>
                <div style="font-size: 12px; color: #64748b;">${h.tx_count} transactions &bull; Top: ${escapeHtml(h.top_category)}</div>
              </div>
              <div style="font-size: 12px; margin-bottom: 12px; color: #475569;">
                Target: ${formatINR(h.monthly_budget)} (${h.pct_used}% used)
              </div>
              <div style="display: flex; gap: 8px;">
                <button type="button" class="btn btn-sm btn-primary" onclick="viewHistoryMonth('${h.period}')" style="flex: 1;">
                  <i class="fa-solid fa-eye"></i> View Month
                </button>
                <a href="/api/export/pdf?year=${h.year}&month=${h.month}" class="btn btn-sm btn-secondary" title="Download PDF Statement">
                  <i class="fa-solid fa-file-pdf"></i> PDF
                </a>
              </div>
            </div>
          `;
        }).join('');
      }
    }

    // Populate month filter dropdown in History tab
    if (monthSelect) {
      monthSelect.innerHTML = '<option value="all">All Past Months</option>';
      historyList.forEach(h => {
        const opt = document.createElement('option');
        opt.value = h.period;
        opt.textContent = `${h.label} (${formatINR(h.total_spend)})`;
        monthSelect.appendChild(opt);
      });

      monthSelect.onchange = () => filterHistoryTable(historyList);
    }

    if (searchInput) {
      searchInput.oninput = () => filterHistoryTable(historyList);
    }

    // Initial table render
    filterHistoryTable(historyList);

  } catch (err) {
    console.error("Error loading expense history:", err);
  }
}

async function filterHistoryTable(historyList) {
  const monthSelect = document.getElementById('history-month-select');
  const searchInput = document.getElementById('history-search-input');
  const tableBody = document.getElementById('history-table-body');
  const countText = document.getElementById('history-showing-count');

  const selectedPeriod = monthSelect ? monthSelect.value : 'all';
  const query = searchInput ? searchInput.value.trim().toLowerCase() : '';

  let url = '/api/expenses?';
  if (selectedPeriod !== 'all') {
    const parts = selectedPeriod.split('-');
    const year = parts[0];
    const month = parts[1];
    const startDate = `${year}-${month}-01`;
    const endDate = `${year}-${month}-31`;
    url += `start_date=${startDate}&end_date=${endDate}&`;
  }
  if (query) {
    url += `search=${encodeURIComponent(query)}`;
  }

  try {
    const res = await fetch(url);
    const data = await res.json();
    const expenses = data.expenses || [];

    if (tableBody) {
      if (expenses.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="8" class="text-center text-muted">No historical transactions found for this selection.</td></tr>';
      } else {
        tableBody.innerHTML = expenses.map(e => `
          <tr>
            <td><strong>${e.date}</strong></td>
            <td>${escapeHtml(e.title)}</td>
            <td><span class="badge badge-subtle">${escapeHtml(e.category)}</span></td>
            <td>${escapeHtml(e.payment_method)}</td>
            <td><span class="badge ${e.frequency === 'monthly' ? 'badge-purple' : 'badge-subtle'}">${e.frequency || 'daily'}</span></td>
            <td><strong style="color: var(--primary);">${formatINR(e.amount)}</strong></td>
            <td>${escapeHtml(e.notes || '-')}</td>
            <td>
              <button class="btn-icon" onclick="editExpense(${e.id})" title="Edit"><i class="fa-solid fa-pen-to-square"></i></button>
              <button class="btn-icon text-danger" onclick="deleteExpenseItem(${e.id})" title="Delete"><i class="fa-solid fa-trash-can"></i></button>
            </td>
          </tr>
        `).join('');
      }
    }

    if (countText) {
      countText.textContent = `Showing ${expenses.length} historical transactions`;
    }
  } catch (err) {
    console.error("Error fetching history table:", err);
  }
}

window.viewHistoryMonth = function(periodStr) {
  const periodSelect = document.getElementById('filter-period');
  if (periodSelect) {
    periodSelect.value = periodStr;
    currentFilterPeriod = periodStr;
  }
  // Switch to Overview tab
  const overviewBtn = document.querySelector('.nav-item[data-tab="tab-overview"]');
  if (overviewBtn) overviewBtn.click();
  refreshDashboard();
};

// ----------------------------------------------------
// User Profile & Settings Tab Logic
// ----------------------------------------------------
async function loadUserProfile() {
  try {
    const res = await fetch('/api/user/profile');
    if (!res.ok) {
      if (res.status === 401) {
        window.location.href = '/login';
        return;
      }
      throw new Error(`Server returned ${res.status}`);
    }
    const data = await res.json();
    if (!data.success || !data.profile) {
      showToast(data.error || 'Failed to load profile details.', 'error');
      return;
    }

    const p = data.profile;
    const displayName = p.full_name || p.username || 'User';
    const initial = (displayName.charAt(0) || 'U').toUpperCase();

    // Populate profile inputs
    const inputUsername = document.getElementById('prof-username');
    const inputFullName = document.getElementById('prof-fullname');
    const inputEmail = document.getElementById('prof-email');
    const inputPhone = document.getElementById('prof-phone');

    if (inputUsername) inputUsername.value = p.username || '';
    if (inputFullName) inputFullName.value = p.full_name || '';
    if (inputEmail) inputEmail.value = p.email || '';
    if (inputPhone) inputPhone.value = p.phone || '';

    // Populate profile summary card
    const nameEl = document.getElementById('profile-display-name');
    const initialEl = document.getElementById('profile-avatar-initials');
    const roleEl = document.getElementById('profile-role-badge');
    const joinedEl = document.getElementById('profile-joined-date');
    const countEl = document.getElementById('profile-expense-count');
    const spentEl = document.getElementById('profile-total-spent');

    if (nameEl) nameEl.textContent = displayName;
    if (initialEl) initialEl.textContent = initial;
    if (roleEl) roleEl.textContent = (p.role || 'user').toUpperCase();
    if (joinedEl) joinedEl.textContent = p.created_at ? p.created_at.split(' ')[0] : 'N/A';
    if (countEl) countEl.textContent = Number(p.expense_count || 0).toLocaleString();
    if (spentEl) spentEl.textContent = formatINR(p.total_spent || 0);

    // Sync header and sidebar profile tags live
    document.querySelectorAll('.top-profile-name').forEach(el => el.textContent = p.username);
    document.querySelectorAll('.sidebar-user-name').forEach(el => el.textContent = p.username);
    document.querySelectorAll('.sidebar-user-avatar-initial').forEach(el => el.textContent = (p.username.charAt(0) || 'U').toUpperCase());

  } catch (err) {
    console.error('Error loading user profile:', err);
    showToast('Failed to load profile details.', 'error');
  }
}
window.loadUserProfile = loadUserProfile;

function initProfileListeners() {
  const formProfile = document.getElementById('form-update-profile');
  const formPassword = document.getElementById('form-update-password');

  if (formProfile) {
    formProfile.addEventListener('submit', async (e) => {
      e.preventDefault();
      const saveBtn = document.getElementById('btn-save-profile');
      const originalText = saveBtn ? saveBtn.innerHTML : '';
      if (saveBtn) {
        saveBtn.disabled = true;
        saveBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Saving...';
      }

      const username = (document.getElementById('prof-username')?.value || '').trim();
      const full_name = (document.getElementById('prof-fullname')?.value || '').trim();
      const email = (document.getElementById('prof-email')?.value || '').trim();
      const phone = (document.getElementById('prof-phone')?.value || '').trim();

      try {
        const res = await fetch('/api/user/profile', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, full_name, email, phone })
        });
        const data = await res.json();
        if (data.success) {
          showToast(data.message || 'Profile updated successfully!', 'success');
          await loadUserProfile();
        } else {
          showToast(data.error || 'Failed to update profile.', 'error');
        }
      } catch (err) {
        console.error('Profile update failed:', err);
        showToast('Network error updating profile.', 'error');
      } finally {
        if (saveBtn) {
          saveBtn.disabled = false;
          saveBtn.innerHTML = originalText;
        }
      }
    });
  }

  if (formPassword) {
    formPassword.addEventListener('submit', async (e) => {
      e.preventDefault();
      const currPassword = document.getElementById('prof-curr-password')?.value || '';
      const newPassword = document.getElementById('prof-new-password')?.value || '';
      const confirmPassword = document.getElementById('prof-confirm-password')?.value || '';

      if (newPassword.length < 4) {
        showToast('New password must be at least 4 characters long.', 'error');
        return;
      }

      if (newPassword !== confirmPassword) {
        showToast('New passwords do not match. Please re-enter identical passwords.', 'error');
        return;
      }

      const saveBtn = document.getElementById('btn-save-password');
      const originalText = saveBtn ? saveBtn.innerHTML : '';
      if (saveBtn) {
        saveBtn.disabled = true;
        saveBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Updating...';
      }

      try {
        const res = await fetch('/api/user/profile', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            current_password: currPassword,
            new_password: newPassword
          })
        });
        const data = await res.json();
        if (data.success) {
          showToast(data.message || 'Password changed successfully!', 'success');
          formPassword.reset();
        } else {
          showToast(data.error || 'Failed to change password.', 'error');
        }
      } catch (err) {
        console.error('Password update failed:', err);
        showToast('Network error updating password.', 'error');
      } finally {
        if (saveBtn) {
          saveBtn.disabled = false;
          saveBtn.innerHTML = originalText;
        }
      }
    });
  }
}
window.initProfileListeners = initProfileListeners;

