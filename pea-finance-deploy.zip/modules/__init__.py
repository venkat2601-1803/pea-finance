"""
Personal Expenses Analysis (PEA) - Application Modules Package
Contains decoupled Admin and User blueprints.
"""
