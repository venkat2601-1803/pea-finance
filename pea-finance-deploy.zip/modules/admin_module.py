"""
Personal Expenses Analysis (PEA) - Admin Module
Handles Admin Control Panel, User Management, and Feature Flags Access Control.
"""

from functools import wraps
from flask import Blueprint, render_template, request, jsonify, session, redirect, url_for
import data_manager

admin_bp = Blueprint('admin_module', __name__)


def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            if request.path.startswith('/api/'):
                return jsonify({"success": False, "error": "Authentication required."}), 401
            return redirect(url_for('user_module.login', next=request.url))
        if session.get('role') != 'admin':
            if request.path.startswith('/api/'):
                return jsonify({"success": False, "error": "Access denied. Admin privileges required."}), 403
            return render_template('admin.html', access_denied=True, error="Access Denied. Administrator role required.")
        return f(*args, **kwargs)
    return decorated_function


# ----------------------------------------------------
# Admin Web View
# ----------------------------------------------------

@admin_bp.route('/admin')
@admin_required
def admin_panel():
    """Renders Admin Management Portal."""
    users = data_manager.get_all_users()
    features = data_manager.get_feature_flags()
    return render_template('admin.html', users=users, features=features)


# ----------------------------------------------------
# Admin User Management APIs
# ----------------------------------------------------

@admin_bp.route('/api/admin/users', methods=['GET'])
@admin_required
def api_admin_get_users():
    """List all registered users for admin management."""
    users = data_manager.get_all_users()
    return jsonify({"success": True, "users": users})


@admin_bp.route('/api/admin/users/<int:user_id>/role', methods=['PUT'])
@admin_required
def api_admin_update_role(user_id):
    """Promote or demote user role."""
    data = request.get_json() or {}
    role = data.get('role', 'user')
    success, msg = data_manager.update_user_role(user_id, role)
    if success and user_id == session.get('user_id'):
        session['role'] = role
    return jsonify({"success": success, "message": msg})


@admin_bp.route('/api/admin/users/<int:user_id>/status', methods=['PUT'])
@admin_required
def api_admin_update_status(user_id):
    """Enable or disable user account."""
    data = request.get_json() or {}
    is_active = data.get('is_active', True)
    if user_id == session.get('user_id') and not is_active:
        return jsonify({"success": False, "error": "You cannot deactivate your own admin account."}), 400
    success, msg = data_manager.update_user_status(user_id, is_active)
    return jsonify({"success": success, "message": msg})


@admin_bp.route('/api/admin/users/<int:user_id>/reset-password', methods=['POST'])
@admin_required
def api_admin_reset_password(user_id):
    """Reset password for a user."""
    data = request.get_json() or {}
    new_password = data.get('new_password', '')
    success, msg = data_manager.reset_user_password(user_id, new_password)
    if not success:
        return jsonify({"success": False, "error": msg}), 400
    return jsonify({"success": True, "message": msg})


@admin_bp.route('/api/admin/users/<int:user_id>', methods=['DELETE'])
@admin_required
def api_admin_delete_user(user_id):
    """Delete a user account."""
    if user_id == session.get('user_id'):
        return jsonify({"success": False, "error": "You cannot delete your own admin account."}), 400
    success, msg = data_manager.delete_user(user_id)
    return jsonify({"success": success, "message": msg})


# ----------------------------------------------------
# Admin Feature Flags Management APIs
# ----------------------------------------------------

@admin_bp.route('/api/admin/features', methods=['GET'])
@admin_required
def api_admin_get_features():
    """List all feature flags."""
    features = data_manager.get_feature_flags()
    return jsonify({"success": True, "features": features})


@admin_bp.route('/api/admin/features/<feature_key>', methods=['PUT'])
@admin_required
def api_admin_toggle_feature(feature_key):
    """Enable or disable a feature flag."""
    data = request.get_json() or {}
    is_enabled = data.get('is_enabled', True)
    data_manager.toggle_feature_flag(feature_key, is_enabled)
    return jsonify({"success": True, "message": f"Feature '{feature_key}' updated."})


@admin_bp.route('/api/admin/features', methods=['POST'])
@admin_required
def api_admin_add_feature():
    """Add a new feature flag."""
    data = request.get_json() or {}
    key = data.get('feature_key', '')
    name = data.get('feature_name', '')
    desc = data.get('description', '')
    is_enabled = data.get('is_enabled', True)
    category = data.get('category', 'general')

    success, msg = data_manager.add_feature_flag(key, name, desc, is_enabled, category)
    if not success:
        return jsonify({"success": False, "error": msg}), 400
    return jsonify({"success": True, "message": msg})


@admin_bp.route('/api/admin/features/<feature_key>', methods=['DELETE'])
@admin_required
def api_admin_delete_feature(feature_key):
    """Remove a feature flag."""
    data_manager.delete_feature_flag(feature_key)
    return jsonify({"success": True, "message": f"Feature '{feature_key}' deleted."})


@admin_bp.route('/api/admin/profile', methods=['POST'])
@admin_required
def api_admin_update_profile():
    """Updates logged-in Admin Name and Admin Password."""
    data = request.get_json() or {}
    admin_name = data.get('admin_name', '').strip()
    admin_password = data.get('admin_password', '')
    admin_id = session.get('user_id')

    success, msg = data_manager.update_admin_credentials(admin_id, admin_name, admin_password)
    if success:
        session['username'] = admin_name
        return jsonify({"success": True, "message": msg, "admin_name": admin_name})
    return jsonify({"success": False, "error": msg}), 400
