"""
Personal Expenses Analysis (PEA) - User Module
Handles User Authentication, Personal Finance Dashboard, Daily & Monthly Expense Ledger, Budgets, and One-Click Exports.
"""

import os
import io
import re
import datetime
import pandas as pd
from flask import Blueprint, render_template, request, jsonify, send_file, redirect, url_for, session, flash

import data_manager
import pea_engine
import report_generator

user_bp = Blueprint('user_module', __name__)


def clean_amount(val):
    """Parses numeric amount from string or number, removing currency symbols."""
    if pd.isna(val):
        return 0.0
    s = str(val).strip()
    s = re.sub(r'[₹$€£,]', '', s)
    s = re.sub(r'^(?:Rs\.?|INR)\s*', '', s, flags=re.I)
    if s.startswith('(') and s.endswith(')'):
        s = '-' + s[1:-1]
    try:
        amt = float(s)
        return abs(amt)
    except (ValueError, TypeError):
        return 0.0


def find_col(columns, candidates):
    """Finds best matching column name case-insensitively."""
    cols_clean = {str(col).strip().lower(): col for col in columns}
    for cand in candidates:
        if cand in cols_clean:
            return cols_clean[cand]
    for cand in candidates:
        for col_l, original_col in cols_clean.items():
            if cand in col_l:
                return original_col
    return None


def parse_uploaded_spreadsheet(file_storage):
    """
    Intelligently parses uploaded CSV or Excel file, automatically detecting
    columns and mapping them to standardized transaction tuples.
    """
    filename = getattr(file_storage, 'filename', '') or 'uploaded_file.csv'
    filename_lower = filename.lower()

    if filename_lower.endswith('.csv'):
        try:
            df = pd.read_csv(file_storage, sep=None, engine='python', encoding='utf-8')
        except Exception:
            file_storage.seek(0)
            df = pd.read_csv(file_storage, sep=None, engine='python', encoding='latin-1')
    elif filename_lower.endswith(('.xlsx', '.xls')):
        df = pd.read_excel(file_storage)
    else:
        raise ValueError("Unsupported format. Please upload a .csv, .xlsx, or .xls file.")

    if df.empty:
        raise ValueError("The uploaded spreadsheet contains no data rows.")

    date_col = find_col(df.columns, ['date', 'txn date', 'transaction date', 'posting date', 'timestamp', 'time', 'dt', 'day', 'txn_date'])
    title_col = find_col(df.columns, ['title', 'description', 'desc', 'merchant', 'particulars', 'payee', 'name', 'item', 'narration', 'details'])
    category_col = find_col(df.columns, ['category', 'cat', 'expense type', 'type', 'tag', 'group', 'class', 'head', 'spending category'])
    amount_col = find_col(df.columns, ['debit', 'withdrawal', 'dr', 'amount', 'amt', 'spent', 'expense', 'cost', 'price', 'total', 'value', 'inr'])
    payment_col = find_col(df.columns, ['payment_method', 'payment method', 'payment', 'method', 'mode', 'mode of payment', 'account', 'channel'])
    notes_col = find_col(df.columns, ['notes', 'note', 'remark', 'remarks', 'comment', 'comments', 'narration', 'memo', 'reference'])

    if not amount_col:
        cols_preview = ', '.join([str(c) for c in df.columns[:6]])
        raise ValueError(f"Could not identify an Amount or Debit column. Columns found: [{cols_preview}]")

    date_series = None
    if date_col:
        try:
            date_series = pd.to_datetime(df[date_col], format='mixed', errors='coerce')
        except Exception:
            try:
                date_series = pd.to_datetime(df[date_col], errors='coerce')
            except Exception:
                date_series = None

    today_str = datetime.date.today().strftime('%Y-%m-%d')
    records = []
    total_spent = 0.0
    cats_found = set()

    for idx, row in df.iterrows():
        amt = clean_amount(row.get(amount_col))
        if amt <= 0:
            continue

        total_spent += amt

        date_val = today_str
        if date_series is not None and pd.notna(date_series.iloc[idx]):
            date_val = date_series.iloc[idx].strftime('%Y-%m-%d')
        elif date_col and pd.notna(row.get(date_col)):
            date_val = str(row.get(date_col)).strip()[:10]

        title_val = "Expense Item"
        if title_col and pd.notna(row.get(title_col)):
            t_str = str(row.get(title_col)).strip()
            if t_str:
                title_val = t_str
        elif category_col and pd.notna(row.get(category_col)):
            title_val = f"{row.get(category_col)} Expense"

        cat_val = "General"
        if category_col and pd.notna(row.get(category_col)):
            c_str = str(row.get(category_col)).strip()
            if c_str:
                cat_val = c_str.title()
        cats_found.add(cat_val)

        pay_val = "Other / Direct"
        if payment_col and pd.notna(row.get(payment_col)):
            p_str = str(row.get(payment_col)).strip()
            if p_str:
                pay_val = p_str

        notes_val = ""
        if notes_col and pd.notna(row.get(notes_col)):
            notes_val = str(row.get(notes_col)).strip()

        records.append((date_val, title_val, cat_val, amt, pay_val, notes_val))

    if not records:
        raise ValueError("No valid expense rows with positive amounts were found in the uploaded file.")

    summary = {
        "count": len(records),
        "total_amount": round(total_spent, 2),
        "categories": sorted(list(cats_found))
    }
    return records, summary


def get_engine(month=None, year=None, user_id=None):
    df = data_manager.get_expenses_df(user_id=user_id)
    budgets = data_manager.get_budgets()
    constant_budget = data_manager.get_constant_monthly_budget()
    return pea_engine.ExpenseAnalyticsEngine(df, budgets=budgets, constant_monthly_budget=constant_budget)


# ----------------------------------------------------
# Web Views: Dashboard, Login, Register, Logout
# ----------------------------------------------------

@user_bp.route('/')
def root():
    """Root endpoint always redirects to the login page when site is opened."""
    return redirect(url_for('user_module.login'))


@user_bp.route('/dashboard')
@user_bp.route('/index')
def index():
    """Main Personal Finance Dashboard page."""
    return render_template('index.html')


@user_bp.route('/login', methods=['GET', 'POST'])
def login():
    """Renders login page and authenticates users for User or Admin module."""
    error = None
    selected_role = 'user'
    if request.method == 'POST':
        if request.is_json:
            data = request.get_json() or {}
            username = data.get('username', '')
            password = data.get('password', '')
            login_type = data.get('login_type', 'user')
        else:
            username = request.form.get('username', '')
            password = request.form.get('password', '')
            login_type = request.form.get('login_type', 'user')

        selected_role = login_type
        user = data_manager.verify_user(username, password)

        if isinstance(user, dict) and "error" in user:
            error = user["error"]
            if request.is_json:
                return jsonify({"success": False, "error": error}), 403
        elif user:
            user_role = user.get('role', 'user')

            # If user selected Admin module login, enforce admin role requirement
            if login_type == 'admin' and user_role != 'admin':
                error = "Access Denied: Account does not have Administrator permissions."
                if request.is_json:
                    return jsonify({"success": False, "error": error}), 403
            else:
                session['user_id'] = user['id']
                session['username'] = user['username']
                session['role'] = user_role
                session.permanent = True

                redirect_url = url_for('admin_module.admin_panel') if login_type == 'admin' else url_for('user_module.index')

                if request.is_json:
                    return jsonify({"success": True, "redirect": redirect_url, "username": user['username'], "role": user_role})

                next_url = request.args.get('next') or redirect_url
                return redirect(next_url)
        else:
            error = "Invalid username or password. Default user: user / user123 (Admin: admin / admin123)"
            if request.is_json:
                return jsonify({"success": False, "error": error}), 401

    return render_template('login.html', error=error, selected_role=selected_role)


@user_bp.route('/register', methods=['GET', 'POST'])
def register():
    """Renders registration page and creates new user accounts."""
    if 'user_id' in session:
        return redirect(url_for('user_module.index'))

    error = None
    if request.method == 'POST':
        if request.is_json:
            data = request.get_json() or {}
            username = data.get('username', '')
            password = data.get('password', '')
            confirm_password = data.get('confirm_password', '')
            role = data.get('role', 'user')
        else:
            username = request.form.get('username', '')
            password = request.form.get('password', '')
            confirm_password = request.form.get('confirm_password', '')
            role = 'user'

        if password != confirm_password:
            error = "Passwords do not match."
            if request.is_json:
                return jsonify({"success": False, "error": error}), 400
        else:
            user, err = data_manager.create_user(username, password, role=role)
            if err:
                error = err
                if request.is_json:
                    return jsonify({"success": False, "error": error}), 400
            else:
                session['user_id'] = user['id']
                session['username'] = user['username']
                session['role'] = user.get('role', 'user')
                session.permanent = True
                
                if request.is_json:
                    return jsonify({"success": True, "redirect": url_for('user_module.index'), "username": user['username']})
                return redirect(url_for('user_module.index'))

    return render_template('register.html', error=error)


@user_bp.route('/logout', methods=['GET', 'POST'])
def logout():
    """Logs the user out by clearing the session."""
    session.clear()
    if request.is_json:
        return jsonify({"success": True, "redirect": url_for('user_module.login')})
    return redirect(url_for('user_module.login'))


# ----------------------------------------------------
# REST API Endpoints: Auth Status & Summary
# ----------------------------------------------------

@user_bp.route('/api/auth/login', methods=['POST'])
def api_login():
    return login()


@user_bp.route('/api/auth/register', methods=['POST'])
def api_register():
    return register()


@user_bp.route('/api/auth/status', methods=['GET'])
def api_auth_status():
    if 'user_id' in session:
        return jsonify({
            "authenticated": True,
            "user_id": session['user_id'],
            "username": session['username'],
            "role": session.get('role', 'user'),
            "features": data_manager.get_feature_flags_dict()
        })
    return jsonify({"authenticated": False}), 200


@user_bp.route('/api/summary', methods=['GET'])
def api_summary():
    """Returns high-level KPIs, category analysis, budget variance, and anomalies."""
    month = request.args.get('month', None)
    year = request.args.get('year', None)
    if month == 'all':
        month = None
    if year == 'all':
        year = None

    user_id = session.get('user_id', 1)
    engine = get_engine(user_id=user_id)
    kpis = engine.get_summary_kpis(month, year)
    kpis['total_db_count'] = data_manager.get_expenses_count(user_id=user_id)
    categories = engine.get_category_breakdown(month, year)
    budget_vs_actual = engine.get_budget_vs_actual(month, year)
    anomalies = engine.detect_anomalies(threshold_z=2.0)
    recent_expenses = engine.get_recent_expenses(n=10, filter_month=month, filter_year=year)

    return jsonify({
        "success": True,
        "kpis": kpis,
        "categories": categories,
        "budget_vs_actual": budget_vs_actual,
        "anomalies": anomalies,
        "top_expenses": recent_expenses
    })


@user_bp.route('/api/charts/category', methods=['GET'])
def api_chart_category():
    month = request.args.get('month', None)
    year = request.args.get('year', None)
    if month == 'all': month = None
    if year == 'all': year = None

    user_id = session.get('user_id', 1)
    engine = get_engine(user_id=user_id)
    breakdown = engine.get_category_breakdown(month, year)

    labels = [item['category'] for item in breakdown]
    values = [item['total_amount'] for item in breakdown]
    percentages = [item['percentage'] for item in breakdown]
    color_palette = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899', '#06B6D4', '#84CC16', '#6366F1', '#14B8A6']

    return jsonify({
        "labels": labels,
        "values": values,
        "percentages": percentages,
        "colors": color_palette[:len(labels)]
    })


@user_bp.route('/api/charts/monthly', methods=['GET'])
def api_chart_monthly():
    user_id = session.get('user_id', 1)
    engine = get_engine(user_id=user_id)
    trends = engine.get_monthly_trends()
    return jsonify(trends)


@user_bp.route('/api/charts/budget', methods=['GET'])
def api_chart_budget():
    month = request.args.get('month', None)
    year = request.args.get('year', None)
    if month == 'all': month = None
    if year == 'all': year = None

    user_id = session.get('user_id', 1)
    engine = get_engine(user_id=user_id)
    bva = engine.get_budget_vs_actual(month, year)

    return jsonify({
        "labels": [item['category'] for item in bva],
        "actuals": [item['actual'] for item in bva],
        "budgets": [item['budget'] for item in bva],
        "statuses": [item['status'] for item in bva]
    })


@user_bp.route('/api/charts/dow', methods=['GET'])
def api_chart_dow():
    month = request.args.get('month', None)
    year = request.args.get('year', None)
    if month == 'all': month = None
    if year == 'all': year = None

    user_id = session.get('user_id', 1)
    engine = get_engine(user_id=user_id)
    return jsonify(engine.get_day_of_week_analysis(month, year))


@user_bp.route('/api/charts/payment', methods=['GET'])
def api_chart_payment():
    month = request.args.get('month', None)
    year = request.args.get('year', None)
    if month == 'all': month = None
    if year == 'all': year = None

    user_id = session.get('user_id', 1)
    engine = get_engine(user_id=user_id)
    return jsonify(engine.get_payment_method_breakdown(month, year))


@user_bp.route('/api/filter-options', methods=['GET'])
def api_filter_options():
    user_id = session.get('user_id', 1)
    engine = get_engine(user_id=user_id)
    today_ym = datetime.date.today().strftime('%Y-%m')
    months = engine.get_available_months()

    # Ensure current month is represented in months list
    has_current = any(m['value'] == today_ym for m in months)
    if not has_current:
        today_date = datetime.date.today()
        months.insert(0, {
            "value": today_ym,
            "label": today_date.strftime("%B %Y")
        })

    return jsonify({
        "current_month": today_ym,
        "months": months,
        "categories": data_manager.get_distinct_categories(),
        "payment_methods": data_manager.get_distinct_payment_methods()
    })


@user_bp.route('/api/history', methods=['GET'])
def api_history():
    """Returns monthly historical expense archives for past months auditing and statements."""
    user_id = session.get('user_id', 1)
    df = data_manager.get_expenses_df(user_id=user_id)
    constant_budget = data_manager.get_constant_monthly_budget()

    today_ym = datetime.date.today().strftime('%Y-%m')

    if df.empty:
        return jsonify({
            "success": True,
            "current_month": today_ym,
            "history": []
        })

    df_copy = df.copy()
    df_copy['ym'] = df_copy['date'].dt.to_period('M')
    grouped = df_copy.groupby('ym')

    history_list = []
    for ym, group in grouped:
        year, month = ym.year, ym.month
        month_str = f"{year:04d}-{month:02d}"
        month_label = ym.strftime("%B %Y")
        total_spend = float(group['amount'].sum())
        tx_count = int(len(group))

        cat_sums = group.groupby('category')['amount'].sum()
        top_cat = cat_sums.idxmax() if not cat_sums.empty else "N/A"
        top_cat_amt = float(cat_sums.max()) if not cat_sums.empty else 0.0

        is_current = (month_str == today_ym)

        history_list.append({
            "period": month_str,
            "label": month_label,
            "year": year,
            "month": month,
            "total_spend": round(total_spend, 2),
            "tx_count": tx_count,
            "top_category": top_cat,
            "top_category_amount": round(top_cat_amt, 2),
            "monthly_budget": round(constant_budget, 2),
            "variance": round(constant_budget - total_spend, 2),
            "pct_used": round((total_spend / constant_budget * 100), 1) if constant_budget > 0 else 0.0,
            "is_current": is_current
        })

    history_list.sort(key=lambda x: x['period'], reverse=True)
    return jsonify({
        "success": True,
        "current_month": today_ym,
        "history": history_list
    })


# ----------------------------------------------------
# Transactions Ledger CRUD API (Daily / Monthly)
# ----------------------------------------------------

@user_bp.route('/api/expenses', methods=['GET'])
def api_get_expenses():
    start_date = request.args.get('start_date') or None
    end_date = request.args.get('end_date') or None
    category = request.args.get('category') or None
    search = request.args.get('search') or None
    frequency = request.args.get('frequency') or None
    user_id = session.get('user_id')

    expenses = data_manager.get_all_expenses_list(start_date, end_date, category, search, user_id=user_id, frequency=frequency)
    if not expenses and user_id is not None:
        expenses = data_manager.get_all_expenses_list(start_date, end_date, category, search, user_id=None, frequency=frequency)

    return jsonify({"success": True, "count": len(expenses), "expenses": expenses})


@user_bp.route('/api/expenses', methods=['POST'])
def api_add_expense():
    data = request.json or {}
    date_val = data.get('date', datetime.date.today().strftime('%Y-%m-%d'))
    title = data.get('title', '').strip()
    category = data.get('category', 'Others')
    amount = float(data.get('amount', 0.0))
    payment_method = data.get('payment_method', 'Credit Card')
    notes = data.get('notes', '')
    frequency = data.get('frequency', 'daily')
    user_id = session.get('user_id', 1)

    if not title:
        return jsonify({"success": False, "error": "Item title is required."}), 400
    if amount <= 0:
        return jsonify({"success": False, "error": "Amount must be greater than zero."}), 400

    new_id = data_manager.add_expense(date_val, title, category, amount, payment_method, notes, frequency, user_id)
    return jsonify({"success": True, "id": new_id, "message": f"{frequency.capitalize()} expense added successfully."})


@user_bp.route('/api/expenses/bulk-manual', methods=['POST'])
def api_add_bulk_manual_expenses():
    """Inserts a list of manually typed expense items in bulk."""
    data = request.json or {}
    items = data.get('items', [])
    if not items or not isinstance(items, list):
        return jsonify({"success": False, "error": "No manual items provided."}), 400

    user_id = session.get('user_id', 1)
    today_str = datetime.date.today().strftime('%Y-%m-%d')
    added_count = 0

    for item in items:
        title = str(item.get('title', '')).strip()
        try:
            amt = float(item.get('amount', 0))
        except (ValueError, TypeError):
            amt = 0.0

        if not title or amt <= 0:
            continue

        date_val = str(item.get('date', '')).strip() or today_str
        cat = str(item.get('category', 'Others')).strip() or 'Others'
        pay = str(item.get('payment_method', 'UPI (GPay / PhonePe / Paytm)')).strip() or 'UPI'
        freq = str(item.get('frequency', 'daily')).strip() or 'daily'
        notes = str(item.get('notes', '')).strip()

        data_manager.add_expense(date_val, title, cat, amt, pay, notes, freq, user_id)
        added_count += 1

    if added_count == 0:
        return jsonify({"success": False, "error": "No valid manual expense items with positive amounts were provided."}), 400

    return jsonify({"success": True, "count": added_count, "message": f"Successfully saved {added_count} manual expense records."})


@user_bp.route('/api/expenses/<int:expense_id>', methods=['PUT'])
def api_update_expense(expense_id):
    data = request.json or {}
    date_val = data.get('date')
    title = data.get('title', '').strip()
    category = data.get('category')
    amount = float(data.get('amount', 0.0))
    payment_method = data.get('payment_method')
    notes = data.get('notes', '')
    frequency = data.get('frequency', 'daily')
    user_id = session.get('user_id', 1)

    if not title or amount <= 0:
        return jsonify({"success": False, "error": "Valid title and positive amount required."}), 400

    data_manager.update_expense(expense_id, date_val, title, category, amount, payment_method, notes, frequency, user_id)
    return jsonify({"success": True, "message": "Expense updated successfully."})


@user_bp.route('/api/expenses/<int:expense_id>', methods=['DELETE'])
def api_delete_expense(expense_id):
    data_manager.delete_expense(expense_id)
    return jsonify({"success": True, "message": "Expense deleted successfully."})


# ----------------------------------------------------
# Budgets API
# ----------------------------------------------------

@user_bp.route('/api/budgets', methods=['GET'])
def api_get_budgets():
    budgets = data_manager.get_budgets()
    constant_budget = data_manager.get_constant_monthly_budget()
    return jsonify({
        "success": True,
        "budgets": budgets,
        "constant_monthly_budget": constant_budget
    })


@user_bp.route('/api/budgets', methods=['POST'])
def api_save_budgets():
    data = request.json or {}
    for cat, budget_val in data.items():
        try:
            val = float(budget_val)
            if val >= 0:
                data_manager.update_budget(cat, val)
        except ValueError:
            pass

    # Update persistent constant overall monthly budget target to match sum of category budgets
    updated_budgets = data_manager.get_budgets()
    total_constant = sum(updated_budgets.values())
    data_manager.set_constant_monthly_budget(total_constant)

    return jsonify({
        "success": True,
        "message": f"Category budgets updated successfully. Constant monthly target saved as ₹{total_constant:,.2f}.",
        "constant_monthly_budget": total_constant
    })


@user_bp.route('/api/budgets/constant', methods=['POST'])
def api_set_constant_budget():
    """Sets a constant overall monthly budget cap that stays fixed across all months until explicitly changed by the user."""
    data = request.json or {}
    try:
        total_target = float(data.get('total_monthly_budget', 0))
    except (ValueError, TypeError):
        total_target = 0.0

    if total_target <= 0:
        return jsonify({"success": False, "error": "Please enter a valid positive monthly budget amount."}), 400

    # Save and persist constant monthly budget in settings
    data_manager.set_constant_monthly_budget(total_target)

    categories = data_manager.get_distinct_categories()
    if not categories:
        categories = data_manager.DEFAULT_CATEGORIES

    existing_budgets = data_manager.get_budgets()
    existing_sum = sum(existing_budgets.values())

    if existing_sum > 0:
        # Scale existing category budgets proportionally to match new total target
        ratio = total_target / existing_sum
        for cat, old_val in existing_budgets.items():
            new_val = round(old_val * ratio, 2)
            data_manager.update_budget(cat, new_val)
    else:
        weights = {
            "Food & Dining": 0.25,
            "Bills & Utilities": 0.20,
            "Transportation": 0.12,
            "Shopping": 0.12,
            "Education": 0.12,
            "Healthcare": 0.08,
            "Entertainment": 0.06,
            "Others": 0.05
        }
        n_cats = len(categories)
        weight_sum = sum(weights.get(c, 0.10) for c in categories)

        for cat in categories:
            w = weights.get(cat, 0.10) / weight_sum if weight_sum > 0 else (1.0 / n_cats)
            cat_budget = round(total_target * w, 2)
            data_manager.update_budget(cat, cat_budget)

    return jsonify({
        "success": True,
        "total_budget": total_target,
        "constant_monthly_budget": total_target,
        "message": f"Monthly budget target updated to ₹{total_target:,.2f}."
    })


# ----------------------------------------------------
# Exports and Spreadsheet Upload
# ----------------------------------------------------

@user_bp.route('/api/export/pdf', methods=['GET'])
def export_pdf():
    month = request.args.get('month', None)
    year = request.args.get('year', None)
    if month == 'all': month = None
    if year == 'all': year = None

    period_name = "All Time"
    if month and year:
        period_name = f"{datetime.date(int(year), int(month), 1).strftime('%B %Y')}"
    elif year:
        period_name = f"Year {year}"

    user_id = session.get('user_id', 1)
    engine = get_engine(user_id=user_id)
    kpis = engine.get_summary_kpis(month, year)
    categories = engine.get_category_breakdown(month, year)
    top_expenses = engine.get_top_expenses(n=10, filter_month=month, filter_year=year)

    pdf_buffer = report_generator.generate_pdf_report(kpis, categories, top_expenses, period_name)
    filename = f"PEA_Financial_Report_{datetime.date.today().strftime('%Y%m%d')}.pdf"
    return send_file(pdf_buffer, mimetype='application/pdf', as_attachment=True, download_name=filename)


@user_bp.route('/api/export/excel', methods=['GET'])
def export_excel():
    user_id = session.get('user_id', 1)
    engine = get_engine(user_id=user_id)
    df = data_manager.get_expenses_df(user_id=user_id)
    budgets = data_manager.get_budgets()
    kpis = engine.get_summary_kpis()
    categories = engine.get_category_breakdown()

    excel_buffer = report_generator.generate_excel_report(df, kpis, categories, budgets)
    filename = f"PEA_Expenses_Analysis_{datetime.date.today().strftime('%Y%m%d')}.xlsx"
    return send_file(excel_buffer, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', as_attachment=True, download_name=filename)


@user_bp.route('/api/export/csv', methods=['GET'])
def export_csv():
    user_id = session.get('user_id', 1)
    df = data_manager.get_expenses_df(user_id=user_id)
    csv_buffer = io.StringIO()
    df.to_csv(csv_buffer, index=False)
    mem_buffer = io.BytesIO(csv_buffer.getvalue().encode('utf-8'))

    filename = f"PEA_Transactions_Ledger_{datetime.date.today().strftime('%Y%m%d')}.csv"
    return send_file(mem_buffer, mimetype='text/csv', as_attachment=True, download_name=filename)


@user_bp.route('/api/upload-data', methods=['POST'])
@user_bp.route('/api/import-csv', methods=['POST'])
def api_upload_data():
    if 'file' not in request.files:
        return jsonify({"success": False, "error": "No file uploaded. Please select a CSV or Excel file."}), 400

    file = request.files['file']
    if not file or not file.filename:
        return jsonify({"success": False, "error": "No file selected."}), 400

    replace_param = request.form.get('replace_existing', 'true').lower()
    replace_existing = replace_param in ('true', '1', 'yes')

    try:
        records, summary = parse_uploaded_spreadsheet(file)
        if not records:
            return jsonify({"success": False, "error": "No valid expense rows found in the uploaded file."}), 400

        user_id = session.get('user_id', 1)
        inserted_count = data_manager.bulk_add_expenses(records, replace_existing=replace_existing, user_id=user_id)
        return jsonify({
            "success": True,
            "count": inserted_count,
            "filename": file.filename,
            "summary": summary,
            "message": f"Successfully loaded {inserted_count} transactions from {file.filename}."
        })
    except ValueError as ve:
        return jsonify({"success": False, "error": str(ve)}), 400
    except Exception as e:
        return jsonify({"success": False, "error": f"Error processing spreadsheet: {str(e)}"}), 500


@user_bp.route('/api/status', methods=['GET'])
def api_status():
    user_id = session.get('user_id')
    count = data_manager.get_expenses_count(user_id=user_id)
    return jsonify({"success": True, "count": count, "has_data": count > 0})


@user_bp.route('/api/reset-data', methods=['POST'])
@user_bp.route('/api/clear-data', methods=['POST'])
def api_clear_data():
    user_id = session.get('user_id')
    data_manager.clear_all_expenses(user_id=user_id)
    return jsonify({"success": True, "message": "Your expense data has been cleared."})


@user_bp.route('/api/user/profile', methods=['GET'])
def api_get_profile():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"success": False, "error": "Not authenticated."}), 401
    profile = data_manager.get_user_profile(user_id)
    if not profile:
        return jsonify({"success": False, "error": "User profile not found."}), 404
    return jsonify({"success": True, "profile": profile})


@user_bp.route('/api/user/profile', methods=['POST', 'PUT'])
def api_update_profile():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"success": False, "error": "Not authenticated."}), 401

    data = request.get_json(silent=True) or request.form.to_dict()
    username = data.get('username')
    full_name = data.get('full_name')
    email = data.get('email')
    phone = data.get('phone')
    current_password = data.get('current_password')
    new_password = data.get('new_password')

    success, message, updated_user = data_manager.update_user_profile(
        user_id=user_id,
        username=username,
        full_name=full_name,
        email=email,
        phone=phone,
        current_password=current_password,
        new_password=new_password
    )

    if not success:
        return jsonify({"success": False, "error": message}), 400

    if updated_user and 'username' in updated_user:
        session['username'] = updated_user['username']

    return jsonify({
        "success": True,
        "message": message,
        "profile": updated_user
    })
