"""
Personal Expenses Analysis (PEA) - Report Generator
Generates one-click professional PDF reports (ReportLab) and styled multi-sheet Excel workbooks (openpyxl) in Indian Rupees (₹ / Rs.).
"""

import io
import datetime
import pandas as pd
import numpy as np

# ReportLab imports for PDF generation
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable

# openpyxl imports for Excel generation
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter


def generate_pdf_report(kpis: dict, category_breakdown: list, top_expenses: list, period_name: str = "All Time") -> io.BytesIO:
    """
    Generates a PDF financial summary report in Indian Rupees (Rs. / INR).
    """
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        rightMargin=36,
        leftMargin=36,
        topMargin=36,
        bottomMargin=36
    )

    styles = getSampleStyleSheet()

    # Custom typography styles
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontSize=20,
        leading=24,
        textColor=colors.HexColor('#1E293B'),
        fontName='Helvetica-Bold',
        spaceAfter=4
    )
    subtitle_style = ParagraphStyle(
        'DocSubtitle',
        parent=styles['Normal'],
        fontSize=10,
        leading=14,
        textColor=colors.HexColor('#64748B'),
        spaceAfter=12
    )
    section_heading = ParagraphStyle(
        'SectionHead',
        parent=styles['Heading2'],
        fontSize=12,
        leading=15,
        textColor=colors.HexColor('#0F172A'),
        fontName='Helvetica-Bold',
        spaceBefore=10,
        spaceAfter=6
    )
    cell_style = ParagraphStyle(
        'CellText',
        parent=styles['Normal'],
        fontSize=9,
        leading=11,
        textColor=colors.HexColor('#334155')
    )
    cell_bold = ParagraphStyle(
        'CellBold',
        parent=styles['Normal'],
        fontSize=9,
        leading=11,
        fontName='Helvetica-Bold',
        textColor=colors.HexColor('#0F172A')
    )

    story = []

    # Document Header
    story.append(Paragraph("Personal Expenses Analysis (PEA)", title_style))
    today_str = datetime.datetime.now().strftime("%B %d, %Y at %I:%M %p")
    story.append(Paragraph(f"Financial Analytics & Spending Report &bull; Currency: <b>Indian Rupees (Rs. / INR)</b> &bull; Period: <b>{period_name}</b> &bull; Generated: {today_str}", subtitle_style))
    story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor('#3B82F6'), spaceAfter=12))

    # Section 1: Executive KPI Metrics
    story.append(Paragraph("1. Executive Financial Summary (INR)", section_heading))
    kpi_data = [
        [
            Paragraph("<b>Total Spend</b>", cell_style),
            Paragraph(f"Rs. {kpis.get('total_spend', 0.0):,.2f}", cell_bold),
            Paragraph("<b>Total Monthly Budget</b>", cell_style),
            Paragraph(f"Rs. {kpis.get('total_budget', 0.0):,.2f}", cell_bold)
        ],
        [
            Paragraph("<b>Budget Utilization</b>", cell_style),
            Paragraph(f"{kpis.get('budget_used_pct', 0.0)}%", cell_bold),
            Paragraph("<b>Remaining / Variance</b>", cell_style),
            Paragraph(f"Rs. {kpis.get('budget_remaining', 0.0):,.2f}", cell_bold)
        ],
        [
            Paragraph("<b>Total Transactions</b>", cell_style),
            Paragraph(f"{kpis.get('transaction_count', 0)}", cell_bold),
            Paragraph("<b>Average Transaction</b>", cell_style),
            Paragraph(f"Rs. {kpis.get('avg_spend', 0.0):,.2f}", cell_bold)
        ],
        [
            Paragraph("<b>Daily Average Burn</b>", cell_style),
            Paragraph(f"Rs. {kpis.get('daily_avg_spend', 0.0):,.2f}/day", cell_bold),
            Paragraph("<b>Top Spending Area</b>", cell_style),
            Paragraph(f"{kpis.get('top_category', 'N/A')} (Rs. {kpis.get('top_category_amount', 0.0):,.2f})", cell_bold)
        ]
    ]

    kpi_table = Table(kpi_data, colWidths=[120, 150, 130, 140])
    kpi_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#F8FAFC')),
        ('BOX', (0, 0), (-1, -1), 1, colors.HexColor('#CBD5E1')),
        ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#E2E8F0')),
        ('TOPPADDING', (0, 0), (-1, -1), 5),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
    ]))
    story.append(kpi_table)
    story.append(Spacer(1, 12))

    # Section 2: Category Breakdown & Budget Comparison
    story.append(Paragraph("2. Category Spending & Budget Variance (in Rupees)", section_heading))
    cat_headers = [
        Paragraph("<b>Category</b>", cell_bold),
        Paragraph("<b>Actual (Rs.)</b>", cell_bold),
        Paragraph("<b>Budget (Rs.)</b>", cell_bold),
        Paragraph("<b>Variance (Rs.)</b>", cell_bold),
        Paragraph("<b>Share %</b>", cell_bold),
        Paragraph("<b>Status</b>", cell_bold)
    ]
    cat_rows = [cat_headers]

    for item in category_breakdown:
        status_text = item['status']
        if status_text == 'Exceeded':
            status_html = f"<font color='#DC2626'><b>{status_text}</b></font>"
        elif status_text == 'Warning':
            status_html = f"<font color='#D97706'><b>{status_text}</b></font>"
        else:
            status_html = f"<font color='#16A34A'><b>{status_text}</b></font>"

        cat_rows.append([
            Paragraph(item['category'], cell_style),
            Paragraph(f"Rs. {item['total_amount']:,.2f}", cell_style),
            Paragraph(f"Rs. {item['budget']:,.2f}", cell_style),
            Paragraph(f"Rs. {item['variance']:,.2f}", cell_style),
            Paragraph(f"{item['percentage']}%", cell_style),
            Paragraph(status_html, cell_style)
        ])

    cat_table = Table(cat_rows, colWidths=[140, 80, 80, 80, 70, 90])
    cat_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#0F172A')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#CBD5E1')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F8FAFC')]),
        ('TOPPADDING', (0, 1), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 1), (-1, -1), 4),
    ]))
    story.append(cat_table)
    story.append(Spacer(1, 12))

    # Section 3: Major Single Spending Transactions
    story.append(Paragraph("3. Major Single Spending Transactions (INR)", section_heading))
    tx_headers = [
        Paragraph("<b>Date</b>", cell_bold),
        Paragraph("<b>Item / Description</b>", cell_bold),
        Paragraph("<b>Category</b>", cell_bold),
        Paragraph("<b>Payment Method</b>", cell_bold),
        Paragraph("<b>Amount (Rs.)</b>", cell_bold)
    ]
    tx_rows = [tx_headers]

    for tx in top_expenses[:8]:
        tx_rows.append([
            Paragraph(tx['date'], cell_style),
            Paragraph(tx['title'], cell_style),
            Paragraph(tx['category'], cell_style),
            Paragraph(tx['payment_method'], cell_style),
            Paragraph(f"Rs. {tx['amount']:,.2f}", cell_bold)
        ])

    tx_table = Table(tx_rows, colWidths=[70, 180, 110, 100, 80])
    tx_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#334155')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#CBD5E1')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F8FAFC')]),
        ('TOPPADDING', (0, 1), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 1), (-1, -1), 4),
    ]))
    story.append(tx_table)

    doc.build(story)
    buffer.seek(0)
    return buffer


def generate_excel_report(df_expenses: pd.DataFrame, kpis: dict, category_breakdown: list, budgets: dict) -> io.BytesIO:
    """
    Generates a professional, multi-sheet Excel workbook with Indian Rupee (₹) styling.
    """
    buffer = io.BytesIO()
    wb = openpyxl.Workbook()

    # ----------------------------------------------------
    # Sheet 1: Executive Summary
    # ----------------------------------------------------
    ws_summary = wb.active
    ws_summary.title = "Executive Summary"
    ws_summary.views.sheetView[0].showGridLines = True

    header_fill = PatternFill(start_color="1E293B", end_color="1E293B", fill_type="solid")
    header_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    title_font = Font(name="Calibri", size=16, bold=True, color="0F172A")
    subtitle_font = Font(name="Calibri", size=10, italic=True, color="64748B")
    section_font = Font(name="Calibri", size=12, bold=True, color="1E3A8A")
    card_fill = PatternFill(start_color="F1F5F9", end_color="F1F5F9", fill_type="solid")
    thin_border = Border(
        left=Side(style='thin', color='CBD5E1'),
        right=Side(style='thin', color='CBD5E1'),
        top=Side(style='thin', color='CBD5E1'),
        bottom=Side(style='thin', color='CBD5E1')
    )

    ws_summary['A1'] = "Personal Expenses Analysis (PEA) - Financial Report (INR)"
    ws_summary['A1'].font = title_font
    ws_summary['A2'] = f"Currency: Indian Rupees (₹) | Generated on {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')} | Powered by Pandas & NumPy"
    ws_summary['A2'].font = subtitle_font

    ws_summary['A4'] = "Key Financial Performance Indicators (₹ INR)"
    ws_summary['A4'].font = section_font

    kpi_items = [
        ("Total Spend", f"₹{kpis.get('total_spend', 0.0):,.2f}"),
        ("Monthly Budget", f"₹{kpis.get('total_budget', 0.0):,.2f}"),
        ("Budget Utilization", f"{kpis.get('budget_used_pct', 0.0)}%"),
        ("Budget Remaining", f"₹{kpis.get('budget_remaining', 0.0):,.2f}"),
        ("Total Transactions", str(kpis.get('transaction_count', 0))),
        ("Average Spend / Tx", f"₹{kpis.get('avg_spend', 0.0):,.2f}"),
        ("Top Spending Category", f"{kpis.get('top_category', 'N/A')}")
    ]

    for col_idx, (label, val) in enumerate(kpi_items, start=1):
        cell_label = ws_summary.cell(row=5, column=col_idx, value=label)
        cell_val = ws_summary.cell(row=6, column=col_idx, value=val)

        cell_label.font = Font(name="Calibri", size=9, bold=True, color="475569")
        cell_label.fill = card_fill
        cell_label.alignment = Alignment(horizontal="center")
        cell_label.border = thin_border

        cell_val.font = Font(name="Calibri", size=12, bold=True, color="0F172A")
        cell_val.fill = card_fill
        cell_val.alignment = Alignment(horizontal="center")
        cell_val.border = thin_border

    ws_summary['A8'] = "Category Spending & Budget Variance Analysis (₹ INR)"
    ws_summary['A8'].font = section_font

    headers = ["Category", "Actual Spent (₹)", "Budget (₹)", "Variance (₹)", "Share of Spend (%)", "Status"]
    for col_idx, h in enumerate(headers, start=1):
        cell = ws_summary.cell(row=9, column=col_idx, value=h)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center")
        cell.border = thin_border

    for row_idx, item in enumerate(category_breakdown, start=10):
        c1 = ws_summary.cell(row=row_idx, column=1, value=item['category'])
        c2 = ws_summary.cell(row=row_idx, column=2, value=item['total_amount'])
        c3 = ws_summary.cell(row=row_idx, column=3, value=item['budget'])
        c4 = ws_summary.cell(row=row_idx, column=4, value=item['variance'])
        c5 = ws_summary.cell(row=row_idx, column=5, value=f"{item['percentage']}%")
        c6 = ws_summary.cell(row=row_idx, column=6, value=item['status'])

        c2.number_format = '"₹"#,##0.00'
        c3.number_format = '"₹"#,##0.00'
        c4.number_format = '"₹"#,##0.00'

        for c in [c1, c2, c3, c4, c5, c6]:
            c.border = thin_border
            c.font = Font(name="Calibri", size=10)

        if item['status'] == 'Exceeded':
            c6.font = Font(name="Calibri", size=10, bold=True, color="DC2626")
        elif item['status'] == 'Warning':
            c6.font = Font(name="Calibri", size=10, bold=True, color="D97706")
        else:
            c6.font = Font(name="Calibri", size=10, bold=True, color="16A34A")

    for col in ws_summary.columns:
        max_len = max(len(str(cell.value or '')) for cell in col)
        col_letter = get_column_letter(col[0].column)
        ws_summary.column_dimensions[col_letter].width = max(max_len + 3, 14)

    # ----------------------------------------------------
    # Sheet 2: All Transactions Ledger
    # ----------------------------------------------------
    ws_tx = wb.create_sheet(title="Transaction Ledger")
    ws_tx.views.sheetView[0].showGridLines = True

    tx_headers = ["ID", "Date", "Item / Description", "Category", "Amount (₹)", "Payment Method", "Notes"]
    for col_idx, h in enumerate(tx_headers, start=1):
        cell = ws_tx.cell(row=1, column=col_idx, value=h)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center")
        cell.border = thin_border

    if not df_expenses.empty:
        for r_idx, (_, row) in enumerate(df_expenses.iterrows(), start=2):
            date_val = row['date'].strftime("%Y-%m-%d") if hasattr(row['date'], 'strftime') else str(row['date'])
            ws_tx.cell(row=r_idx, column=1, value=row.get('id', r_idx - 1)).border = thin_border
            ws_tx.cell(row=r_idx, column=2, value=date_val).border = thin_border
            ws_tx.cell(row=r_idx, column=3, value=row.get('title', '')).border = thin_border
            ws_tx.cell(row=r_idx, column=4, value=row.get('category', '')).border = thin_border

            amt_cell = ws_tx.cell(row=r_idx, column=5, value=float(row.get('amount', 0.0)))
            amt_cell.number_format = '"₹"#,##0.00'
            amt_cell.border = thin_border

            ws_tx.cell(row=r_idx, column=6, value=row.get('payment_method', '')).border = thin_border
            ws_tx.cell(row=r_idx, column=7, value=row.get('notes', '')).border = thin_border

    for col in ws_tx.columns:
        max_len = max(len(str(cell.value or '')) for cell in col)
        col_letter = get_column_letter(col[0].column)
        ws_tx.column_dimensions[col_letter].width = max(max_len + 3, 12)

    wb.save(buffer)
    buffer.seek(0)
    return buffer
