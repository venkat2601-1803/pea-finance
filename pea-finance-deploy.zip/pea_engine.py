"""
Personal Expenses Analysis (PEA) - Core Analytics Engine
Powered by Pandas and NumPy for deep statistical computation, budget variance,
trend modeling, and anomaly detection.
"""

import pandas as pd
import numpy as np
import datetime


class ExpenseAnalyticsEngine:
    def __init__(self, df: pd.DataFrame, budgets: dict = None, constant_monthly_budget: float = None):
        """
        Initializes the analytics engine with a Pandas DataFrame, budgets dictionary,
        and user constant monthly budget target.
        """
        if df.empty:
            self.df = pd.DataFrame(columns=['id', 'date', 'title', 'category', 'amount', 'payment_method', 'notes'])
        else:
            self.df = df.copy()
            # Ensure correct data types
            if not np.issubdtype(self.df['date'].dtype, np.datetime64):
                self.df['date'] = pd.to_datetime(self.df['date'])
            self.df['amount'] = pd.to_numeric(self.df['amount'], errors='coerce').fillna(0.0)

        self.budgets = budgets or {}
        if constant_monthly_budget is not None and constant_monthly_budget > 0:
            self.constant_monthly_budget = float(constant_monthly_budget)
        else:
            self.constant_monthly_budget = float(np.sum([b for c, b in self.budgets.items() if b > 0])) if self.budgets else 0.0

    def get_summary_kpis(self, filter_month=None, filter_year=None):
        """
        Computes high-level KPI cards:
        - Total spend
        - Transaction count
        - Average transaction size (NumPy mean)
        - Median transaction size (NumPy median)
        - Highest single expense (NumPy max)
        - Budget utilization percentage against constant monthly budget
        - Remaining budget / variance
        """
        df = self._filter_by_month_year(self.df, filter_month, filter_year)

        base_monthly_budget = self.constant_monthly_budget if self.constant_monthly_budget > 0 else (
            float(np.sum([b for c, b in self.budgets.items() if b > 0])) if self.budgets else 0.0
        )

        if df.empty:
            return {
                "total_spend": 0.0,
                "transaction_count": 0,
                "avg_spend": 0.0,
                "median_spend": 0.0,
                "max_spend": 0.0,
                "std_spend": 0.0,
                "total_budget": round(base_monthly_budget, 2),
                "budget_used_pct": 0.0,
                "budget_remaining": round(base_monthly_budget, 2),
                "daily_avg_spend": 0.0,
                "top_category": "N/A",
                "top_category_amount": 0.0
            }

        amounts = df['amount'].to_numpy()
        total_spend = float(np.sum(amounts))
        transaction_count = int(len(amounts))
        avg_spend = float(np.mean(amounts))
        median_spend = float(np.median(amounts))
        max_spend = float(np.max(amounts))
        std_spend = float(np.std(amounts))

        # Date range for daily burn rate calculation
        min_date = df['date'].min()
        max_date = df['date'].max()
        days_span = max((max_date - min_date).days + 1, 1)
        daily_avg_spend = float(total_spend / days_span)

        # Budget calculation based on user constant monthly target
        total_budget = base_monthly_budget

        budget_used_pct = round((total_spend / total_budget * 100), 1) if total_budget > 0 else 0.0
        budget_remaining = round(total_budget - total_spend, 2) if total_budget > 0 else 0.0

        # Top category
        category_sums = df.groupby('category')['amount'].sum()
        if not category_sums.empty:
            top_cat = category_sums.idxmax()
            top_cat_amt = float(category_sums.max())
        else:
            top_cat = "N/A"
            top_cat_amt = 0.0

        return {
            "total_spend": round(total_spend, 2),
            "transaction_count": transaction_count,
            "avg_spend": round(avg_spend, 2),
            "median_spend": round(median_spend, 2),
            "max_spend": round(max_spend, 2),
            "std_spend": round(std_spend, 2),
            "total_budget": round(total_budget, 2),
            "budget_used_pct": budget_used_pct,
            "budget_remaining": budget_remaining,
            "daily_avg_spend": round(daily_avg_spend, 2),
            "top_category": top_cat,
            "top_category_amount": round(top_cat_amt, 2)
        }

    def get_category_breakdown(self, filter_month=None, filter_year=None):
        """
        Computes detailed category aggregations using Pandas groupby & NumPy:
        - Total spent per category
        - Count of transactions
        - Percentage of overall spending
        - Average amount per transaction
        - Pareto cumulative share
        """
        df = self._filter_by_month_year(self.df, filter_month, filter_year)

        if df.empty:
            return []

        total_spent = df['amount'].sum()
        if total_spent == 0:
            total_spent = 1e-9  # prevent division by zero

        cat_grouped = df.groupby('category').agg(
            total_amount=('amount', 'sum'),
            tx_count=('amount', 'count'),
            avg_amount=('amount', 'mean'),
            max_amount=('amount', 'max')
        ).reset_index()

        # Sort descending by total amount
        cat_grouped = cat_grouped.sort_values(by='total_amount', ascending=False)

        # NumPy vector calculations
        amounts_arr = cat_grouped['total_amount'].to_numpy()
        percentage_arr = np.round((amounts_arr / total_spent) * 100, 2)
        cumsum_arr = np.cumsum(percentage_arr)

        cat_grouped['percentage'] = percentage_arr
        cat_grouped['cumulative_share'] = np.round(cumsum_arr, 1)

        result = []
        for _, row in cat_grouped.iterrows():
            cat_name = row['category']
            budget_val = self.budgets.get(cat_name, 0.0)
            spent_val = float(row['total_amount'])
            variance = float(budget_val - spent_val)
            pct_budget = round((spent_val / budget_val * 100), 1) if budget_val > 0 else 0.0

            result.append({
                "category": cat_name,
                "total_amount": round(spent_val, 2),
                "tx_count": int(row['tx_count']),
                "avg_amount": round(float(row['avg_amount']), 2),
                "max_amount": round(float(row['max_amount']), 2),
                "percentage": float(row['percentage']),
                "cumulative_share": float(row['cumulative_share']),
                "budget": round(budget_val, 2),
                "variance": round(variance, 2),
                "pct_budget_used": pct_budget,
                "status": "Exceeded" if spent_val > budget_val and budget_val > 0 else (
                    "Warning" if pct_budget >= 80 else "On Track"
                )
            })

        return result

    def get_budget_vs_actual(self, filter_month=None, filter_year=None):
        """
        Compares monthly budget to actual expenses across every category.
        Includes categories that have a budget set even if 0 expenses were incurred.
        """
        df = self._filter_by_month_year(self.df, filter_month, filter_year)
        if df.empty:
            return []

        actual_by_cat = df.groupby('category')['amount'].sum().to_dict()

        if (filter_month is None or filter_month == "all") and not df.empty:
            n_months = max(1, len(df['date'].dt.to_period('M').unique()))
        else:
            n_months = 1

        # Only evaluate categories from the user's data or categories with an active budget
        all_categories = sorted(list(set(list(actual_by_cat.keys()) + [c for c, b in self.budgets.items() if b > 0])))
        comparison = []

        for cat in all_categories:
            budget = float(self.budgets.get(cat, 0.0)) * n_months
            actual = float(actual_by_cat.get(cat, 0.0))
            variance = budget - actual
            pct = round((actual / budget * 100), 1) if budget > 0 else 0.0

            if budget == 0:
                status = "No Budget Set"
                status_color = "secondary"
            elif actual > budget:
                status = "Exceeded"
                status_color = "danger"
            elif pct >= 80.0:
                status = "Warning"
                status_color = "warning"
            else:
                status = "On Track"
                status_color = "success"

            comparison.append({
                "category": cat,
                "budget": round(budget, 2),
                "actual": round(actual, 2),
                "variance": round(variance, 2),
                "pct_used": pct,
                "status": status,
                "status_color": status_color
            })

        # Sort by actual spending descending
        comparison.sort(key=lambda x: x['actual'], reverse=True)
        return comparison

    def get_monthly_trends(self):
        """
        Uses Pandas Resampling and Rolling averages to calculate monthly trend lines:
        - Monthly total spend
        - Transaction count
        - 3-Month Moving Average (NumPy / Pandas rolling)
        - Month-over-Month (MoM) Growth percentage
        """
        if self.df.empty:
            return {"labels": [], "monthly_totals": [], "moving_averages": [], "mom_growth": []}

        df = self.df.copy()
        df = df.set_index('date')

        # Resample by Month End
        monthly = df['amount'].resample('ME').agg(
            total_spend='sum',
            tx_count='count'
        )

        if monthly.empty:
            return {"labels": [], "monthly_totals": [], "moving_averages": [], "mom_growth": []}

        # Format labels: e.g. "Apr 2026"
        labels = [d.strftime("%b %Y") for d in monthly.index]

        # Calculate 3-month moving average
        moving_avg = monthly['total_spend'].rolling(window=3, min_periods=1).mean().round(2).to_list()

        # Month-over-Month growth percentage
        totals = monthly['total_spend'].to_numpy()
        mom_growth = []
        for i in range(len(totals)):
            if i == 0 or totals[i - 1] == 0:
                mom_growth.append(0.0)
            else:
                change = ((totals[i] - totals[i - 1]) / totals[i - 1]) * 100
                mom_growth.append(round(float(change), 1))

        return {
            "labels": labels,
            "monthly_totals": [round(float(x), 2) for x in totals],
            "moving_averages": moving_avg,
            "mom_growth": mom_growth,
            "transaction_counts": monthly['tx_count'].to_list()
        }

    def get_day_of_week_analysis(self, filter_month=None, filter_year=None):
        """
        Calculates spending habits grouped by Day of Week (Monday to Sunday)
        using Pandas datetime properties.
        """
        df = self._filter_by_month_year(self.df, filter_month, filter_year)
        days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

        if df.empty:
            return {
                "days": days,
                "totals": [0.0] * 7,
                "averages": [0.0] * 7,
                "counts": [0] * 7
            }

        df_dow = df.copy()
        df_dow['day_name'] = df_dow['date'].dt.day_name()

        grouped = df_dow.groupby('day_name')['amount'].agg(['sum', 'mean', 'count']).reindex(days).fillna(0.0)

        return {
            "days": days,
            "totals": [round(float(x), 2) for x in grouped['sum']],
            "averages": [round(float(x), 2) for x in grouped['mean']],
            "counts": [int(x) for x in grouped['count']]
        }

    def get_payment_method_breakdown(self, filter_month=None, filter_year=None):
        """
        Breaks down transactions by payment method (UPI, Credit Card, Cash, etc.)
        """
        df = self._filter_by_month_year(self.df, filter_month, filter_year)
        if df.empty:
            return {"labels": [], "values": []}

        pm_group = df.groupby('payment_method')['amount'].sum().sort_values(ascending=False)
        return {
            "labels": list(pm_group.index),
            "values": [round(float(v), 2) for v in pm_group.values]
        }

    def detect_anomalies(self, threshold_z=2.0):
        """
        Detects unusual/abnormal spending spikes using NumPy z-score calculation:
        z = (amount - category_mean) / category_std
        Transactions with z > threshold_z are flagged as outliers/anomalies.
        """
        if self.df.empty or len(self.df) < 5:
            return []

        df = self.df.copy()
        anomalies = []

        for category, cat_df in df.groupby('category'):
            if len(cat_df) < 3:
                continue

            amounts = cat_df['amount'].to_numpy()
            mean = np.mean(amounts)
            std = np.std(amounts)

            if std > 0:
                z_scores = (amounts - mean) / std
                outlier_indices = np.where(z_scores >= threshold_z)[0]

                for idx in outlier_indices:
                    row = cat_df.iloc[idx]
                    anomalies.append({
                        "id": int(row['id']),
                        "date": row['date'].strftime("%Y-%m-%d"),
                        "title": row['title'],
                        "category": category,
                        "amount": float(row['amount']),
                        "category_avg": round(float(mean), 2),
                        "z_score": round(float(z_scores[idx]), 2),
                        "difference_from_mean": round(float(row['amount'] - mean), 2),
                        "payment_method": row['payment_method'],
                        "notes": row['notes']
                    })

        # Sort anomalies by z_score descending
        anomalies.sort(key=lambda x: x['z_score'], reverse=True)
        return anomalies

    def get_recent_expenses(self, n=10, filter_month=None, filter_year=None):
        """Returns the most recent N transactions sorted by date descending, then ID descending."""
        df = self._filter_by_month_year(self.df, filter_month, filter_year)
        if df.empty:
            return []

        recent_df = df.sort_values(by=['date', 'id'], ascending=[False, False]).head(n)
        result = []
        for _, row in recent_df.iterrows():
            date_str = row['date'].strftime("%Y-%m-%d") if hasattr(row['date'], 'strftime') else str(row['date'])
            result.append({
                "id": int(row['id']),
                "date": date_str,
                "title": str(row['title']),
                "category": str(row['category']),
                "amount": round(float(row['amount']), 2),
                "payment_method": str(row.get('payment_method', 'UPI')),
                "notes": str(row.get('notes', ''))
            })
        return result

    def get_top_expenses(self, n=10, filter_month=None, filter_year=None):
        """Returns the most recent transactions for recent expense display."""
        return self.get_recent_expenses(n=n, filter_month=filter_month, filter_year=filter_year)

    def get_available_months(self):
        """Returns distinct year-month combinations in the dataset for filtering."""
        if self.df.empty:
            return []

        dates = self.df['date'].dropna()
        ym_series = dates.dt.to_period('M').drop_duplicates().sort_values(ascending=False)
        return [{"value": str(ym), "label": ym.strftime("%B %Y")} for ym in ym_series]

    def _filter_by_month_year(self, df: pd.DataFrame, month=None, year=None):
        """Helper to filter DataFrame by given month and year if provided."""
        if df.empty or (month is None and year is None):
            return df

        filtered = df.copy()
        if year is not None and year != "all":
            filtered = filtered[filtered['date'].dt.year == int(year)]
        if month is not None and month != "all":
            filtered = filtered[filtered['date'].dt.month == int(month)]

        return filtered
